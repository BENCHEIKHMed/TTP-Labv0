# Project TTP-Lab - Be One And Move Academy

**Auteur**: M. Bencheikh
**Copyright**: © 2025 Mohammed Bencheikh - Be One And Move Academy. Tous droits réservés.

**AVERTISSEMENT LÉGAL : Ce projet est destiné à un usage éducatif et éthique uniquement. Toute distribution, exécution ou utilisation en dehors du cadre pédagogique autorisé est strictement interdite.**

---

## 1. Présentation du Projet

**TTP-Lab** est une plateforme de cyber-entraînement (Cyber Range) conçue pour simuler une chaîne d'attaque complète, de l'accès initial à l'exfiltration de données. Guidée par le framework **MITRE ATT&CK**, elle permet aux étudiants de visualiser concrètement l'impact des actions d'un attaquant et d'apprendre à les détecter.

L'environnement est entièrement conteneurisé avec Docker, garantissant un déploiement simple et reproductible.

### Composants

- **Dashboard (Interface Enseignant)** : Une application web pour contrôler le scénario d'attaque et visualiser les résultats en temps réel.
- **Conteneur Attaquant** : Une machine Ubuntu avec les scripts nécessaires pour mener les attaques.
- **Conteneur Victime** : Une machine Ubuntu hébergeant une application web vulnérable et des outils de surveillance (Sysmon).

## 2. Prérequis

Pour déployer et utiliser TTP-Lab, vous devez avoir les outils suivants installés sur votre machine hôte :

- **Docker** : [Instructions d'installation](https://docs.docker.com/engine/install/)
- **Docker Compose** : [Instructions d'installation](https://docs.docker.com/compose/install/)

Assurez-vous que le service Docker est en cours d'exécution.

## 3. Guide de Déploiement (Étape par Étape)

Le déploiement se fait en une seule commande depuis le répertoire racine du projet.

### Étape 1 : Cloner ou Télécharger le Projet

Assurez-vous d'avoir tous les fichiers du projet dans un seul répertoire sur votre machine.

```bash
# Si vous utilisez git
git clone <URL_DU_PROJET>
cd TTP-Lab
```

### Étape 2 : Lancer l'Environnement

Ouvrez un terminal dans le répertoire racine du projet (où se trouve le fichier `docker-compose.yml`) et exécutez la commande suivante :

```bash
# Cette commande va construire les images Docker et démarrer les 3 conteneurs
docker-compose up --build -d
```

- `--build` : Force la reconstruction des images Docker (utile lors de la première exécution ou après une modification des fichiers).
- `-d` : Lance les conteneurs en mode détaché (en arrière-plan).

Le premier lancement peut prendre quelques minutes, le temps de télécharger les images de base et d'installer les dépendances.

### Étape 3 : Vérifier que les Conteneurs sont Actifs

Pour vérifier que les trois conteneurs (victime, attaquant, dashboard) sont bien en cours d'exécution, utilisez la commande :

```bash
docker ps
```

Vous devriez voir une sortie similaire à celle-ci :

```
CONTAINER ID   IMAGE                 COMMAND                  CREATED         STATUS         PORTS                    NAMES
...
...
...
```

## 4. Utilisation de la Plateforme

### Étape 1 : Accéder au Dashboard

Ouvrez votre navigateur web et accédez à l'adresse suivante :

[http://localhost:8000](http://localhost:8000)

### Étape 2 : Configurer l'Environnement

Dans la section "Configuration de l'Environnement", les adresses IP des conteneurs sont déjà définies par le `docker-compose.yml` :

- **Adresse IP Victime** : `172.20.0.3`
- **Adresse IP Attaquant** : `172.20.0.2`

Cliquez sur **"💾 Enregistrer la Configuration"** pour confirmer ces paramètres dans l'application.

### Étape 3 : Lancer les Attaques

Suivez les phases d'attaque dans l'ordre, de 1 à 6 :

1.  Cliquez sur le bouton **"▶️ Lancer l'Attaque"** pour la Phase 1 (Initial Access).
2.  Observez les résultats dans la **"Console d'Attaque"**.
3.  Cliquez sur **"🔄 Actualiser les Logs"** pour voir les logs Sysmon correspondants générés sur la machine victime.
4.  Analysez la **Timeline** et la **Matrice MITRE ATT&CK** qui se mettent à jour.
5.  Passez à la phase suivante.

**Note pour la Phase 2 (Execution - Reverse Shell)** : Le dashboard simulera l'écoute. Dans un scénario avancé, l'enseignant pourrait se connecter au conteneur attaquant pour recevoir le shell manuellement :

```bash
# Se connecter au conteneur attaquant
docker exec -it ttp-lab-attacker bash

# Lancer le listener netcat
nc -lvnp 4444
```

## 5. Arrêter l'Environnement

Pour arrêter et supprimer tous les conteneurs de TTP-Lab, exécutez la commande suivante depuis le répertoire racine du projet :

```bash
docker-compose down
```

Cette commande arrêtera et supprimera les conteneurs, mais ne supprimera pas les images Docker. Pour une suppression complète, vous pouvez utiliser `docker-compose down --rmi all`.

---

**Fin du guide.** Pour toute question, veuillez vous référer à la documentation de l'académie "Be One And Move".
