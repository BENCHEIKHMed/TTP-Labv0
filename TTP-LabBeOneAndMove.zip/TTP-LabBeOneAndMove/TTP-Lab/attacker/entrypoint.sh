#!/bin/bash
################################################################################
# Script de démarrage de l'environnement Attaquant - TTP-Lab
# Copyright © 2025 Mohammed Bencheikh - Be One And Move Academy
# USAGE ÉDUCATIF ET ÉTHIQUE UNIQUEMENT
################################################################################

echo "=========================================="
echo "  TTP-Lab Attacker Environment"
echo "  Be One And Move Academy"
echo "=========================================="
echo ""
echo "Scripts d'attaque disponibles :"
echo "  - Phase 1 : Initial Access (T1190)"
echo "  - Phase 2 : Execution (T1059.004)"
echo "  - Phase 3 : Persistence (T1053.003)"
echo "  - Phase 4 : Privilege Escalation (T1548.003)"
echo "  - Phase 5 : Collection (T1005)"
echo "  - Phase 6 : Exfiltration (T1041)"
echo ""
echo "Tous les scripts sont contrôlés depuis le Dashboard."
echo "=========================================="
echo ""

# Maintenir le conteneur actif
tail -f /dev/null
