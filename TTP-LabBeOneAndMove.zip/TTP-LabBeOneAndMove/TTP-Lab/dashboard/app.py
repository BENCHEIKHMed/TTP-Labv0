#!/usr/bin/env python3
"""
TTP-Lab Dashboard - Purple Team Command Center
Copyright © 2025 Mohammed Bencheikh - Be One And Move Academy
USAGE ÉDUCATIF ET ÉTHIQUE UNIQUEMENT

Dashboard interactif pour contrôler et visualiser les simulations d'attaque
avec mapping en temps réel sur le framework MITRE ATT&CK.
"""

from flask import Flask, render_template, request, jsonify, send_from_directory
from report_generator import create_report
import subprocess
import json
import os
from datetime import datetime

app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = 'b1m0v3-ttp-lab-2025'

# État global de la simulation
simulation_state = {
    "target_ip": "",
    "target_port": 5000,
    "attacker_ip": "",
    "listener_port": 4444,
    "phases_completed": [],
    "current_phase": None,
    "attack_timeline": [],
    "mitre_coverage": {}
}

# Mapping des phases MITRE ATT&CK
ATTACK_PHASES = {
    "phase1": {
        "id": "phase1",
        "name": "Initial Access",
        "tactic_id": "TA0001",
        "technique_id": "T1190",
        "technique_name": "Exploit Public-Facing Application",
        "description": "Exploitation d'une vulnérabilité d'injection de commande dans l'application web",
        "script": "phase1_initial_access.py",
        "mitre_url": "https://attack.mitre.org/techniques/T1190/",
        "icon": "🎯",
        "color": "#FF6B6B"
    },
    "phase2": {
        "id": "phase2",
        "name": "Execution",
        "tactic_id": "TA0002",
        "technique_id": "T1059.004",
        "technique_name": "Unix Shell",
        "description": "Établissement d'un reverse shell pour obtenir un accès interactif",
        "script": "phase2_execution.py",
        "mitre_url": "https://attack.mitre.org/techniques/T1059/004/",
        "icon": "⚡",
        "color": "#4ECDC4"
    },
    "phase3": {
        "id": "phase3",
        "name": "Persistence",
        "tactic_id": "TA0003",
        "technique_id": "T1053.003",
        "technique_name": "Cron",
        "description": "Création d'une tâche cron pour maintenir l'accès après redémarrage",
        "script": "phase3_persistence.py",
        "mitre_url": "https://attack.mitre.org/techniques/T1053/003/",
        "icon": "🔄",
        "color": "#95E1D3"
    },
    "phase4": {
        "id": "phase4",
        "name": "Privilege Escalation",
        "tactic_id": "TA0004",
        "technique_id": "T1548.003",
        "technique_name": "Sudo and Sudo Caching",
        "description": "Exploitation de sudo mal configuré pour obtenir les privilèges root",
        "script": "phase4_privilege_escalation.py",
        "mitre_url": "https://attack.mitre.org/techniques/T1548/003/",
        "icon": "⬆️",
        "color": "#F38181"
    },
    "phase5": {
        "id": "phase5",
        "name": "Collection",
        "tactic_id": "TA0009",
        "technique_id": "T1005",
        "technique_name": "Data from Local System",
        "description": "Collecte de données sensibles (shadow, passwd, secrets)",
        "script": "phase5_collection.py",
        "mitre_url": "https://attack.mitre.org/techniques/T1005/",
        "icon": "📦",
        "color": "#AA96DA"
    },
    "phase6": {
        "id": "phase6",
        "name": "Exfiltration",
        "tactic_id": "TA0010",
        "technique_id": "T1041",
        "technique_name": "Exfiltration Over C2 Channel",
        "description": "Exfiltration des données via le canal C2 existant",
        "script": "phase6_exfiltration.py",
        "mitre_url": "https://attack.mitre.org/techniques/T1041/",
        "icon": "📤",
        "color": "#FCBAD3"
    }
}

@app.route('/')
def index():
    """Page principale du dashboard"""
    return render_template('index.html', 
                         phases=ATTACK_PHASES,
                         state=simulation_state)

@app.route('/api/configure', methods=['POST'])
def configure():
    """Configure les paramètres de la simulation"""
    data = request.json
    
    simulation_state['target_ip'] = data.get('target_ip', '')
    simulation_state['target_port'] = int(data.get('target_port', 5000))
    simulation_state['attacker_ip'] = data.get('attacker_ip', '')
    simulation_state['listener_port'] = int(data.get('listener_port', 4444))
    
    return jsonify({
        "success": True,
        "message": "Configuration enregistrée",
        "config": simulation_state
    })

@app.route('/api/execute/<phase_id>', methods=['POST'])
def execute_phase(phase_id):
    """Exécute une phase d'attaque spécifique"""
    
    if phase_id not in ATTACK_PHASES:
        return jsonify({"success": False, "error": "Phase inconnue"}), 400
    
    phase = ATTACK_PHASES[phase_id]
    
    # Vérifier que la configuration est complète
    if not simulation_state['target_ip'] or not simulation_state['attacker_ip']:
        return jsonify({
            "success": False,
            "error": "Configuration incomplète. Veuillez configurer les adresses IP."
        }), 400
    
    # Construire la commande
    script_path = f"/opt/attacker/scripts/{phase['script']}"
    
    if phase_id in ["phase1", "phase4", "phase5"]:
        # Phases qui n'ont besoin que de target_ip et target_port
        cmd = [
            "docker", "exec", "ttp-lab-attacker",
            "python3", script_path,
            simulation_state['target_ip'],
            str(simulation_state['target_port'])
        ]
    else:
        # Phases qui nécessitent aussi attacker_ip et listener_port
        cmd = [
            "docker", "exec", "ttp-lab-attacker",
            "python3", script_path,
            simulation_state['target_ip'],
            str(simulation_state['target_port']),
            simulation_state['attacker_ip'],
            str(simulation_state['listener_port'])
        ]
    
    try:
        # Exécution du script
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30
        )
        
        # Enregistrer dans la timeline
        timeline_entry = {
            "timestamp": datetime.now().isoformat(),
            "phase": phase_id,
            "phase_name": phase['name'],
            "technique": phase['technique_id'],
            "tactic": phase['tactic_id'],
            "success": result.returncode == 0,
            "output": result.stdout,
            "error": result.stderr if result.returncode != 0 else None
        }
        
        simulation_state['attack_timeline'].append(timeline_entry)
        
        if result.returncode == 0:
            simulation_state['phases_completed'].append(phase_id)
            simulation_state['mitre_coverage'][phase['technique_id']] = {
                "tactic": phase['tactic_id'],
                "name": phase['technique_name'],
                "executed": True
            }
        
        simulation_state["current_phase"] = phase_id
        
        # Générer le rapport PDF
        report_path = f"/home/ubuntu/TTP-Lab/reports/Rapport_{phase_id}.pdf"
        report_filename = f"Rapport_{phase_id}.pdf"
        
        try:
            # Extraire les données JSON de la sortie du script
            json_output_start = result.stdout.find("{")
            json_output = json.loads(result.stdout[json_output_start:])
            create_report(json_output, report_path)
            print(f"Rapport PDF généré : {report_path}")
        except Exception as e:
            print(f"Erreur lors de la génération du rapport PDF : {e}")
            report_filename = None

        return jsonify({
            "success": result.returncode == 0,
            "phase": phase,
            "output": result.stdout,
            "error": result.stderr,
            "timeline": timeline_entry,
            "report_url": f"/reports/{report_filename}" if report_filename else None
        })
        
    except subprocess.TimeoutExpired:
        return jsonify({
            "success": False,
            "error": "Timeout - L'exécution a pris trop de temps"
        }), 500
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@app.route('/api/logs/victim')
def get_victim_logs():
    """Récupère les logs Sysmon de la victime"""
    try:
        result = subprocess.run(
            ["docker", "exec", "ttp-lab-victim", "tail", "-n", "50", "/var/log/syslog"],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        return jsonify({
            "success": True,
            "logs": result.stdout
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@app.route('/api/state')
def get_state():
    """Retourne l'état actuel de la simulation"""
    return jsonify(simulation_state)

@app.route("/reports/<filename>")
def download_report(filename):
    """Sert les rapports PDF générés"""
    return send_from_directory("/home/ubuntu/TTP-Lab/reports", filename, as_attachment=True)

@app.route("/api/reset", methods=["POST"])
def reset_simulation():
    """Réinitialise l'état de la simulation"""
    simulation_state["phases_completed"] = []
    simulation_state["current_phase"] = None
    simulation_state["attack_timeline"] = []
    simulation_state["mitre_coverage"] = {}
    
    # Supprimer les anciens rapports
    report_dir = "/home/ubuntu/TTP-Lab/reports"
    for f in os.listdir(report_dir):
        os.remove(os.path.join(report_dir, f))
    
    return jsonify({
        "success": True,
        "message": "Simulation réinitialisée"
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)
