#!/usr/bin/env python3
"""
Report Generator for TTP-Lab
Copyright © 2025 Mohammed Bencheikh - Be One And Move Academy
USAGE ÉDUCATIF ET ÉTHIQUE UNIQUEMENT
"""

from fpdf import FPDF
from datetime import datetime
import os

class AttackReportPDF(FPDF):
    def __init__(self):
        super().__init__()
        self.logo_path = "/home/ubuntu/TTP-Lab/dashboard/static/img/logo.jpg"
        self.banner_path = "/home/ubuntu/TTP-Lab/dashboard/static/img/mitre_report_banner.png"
        self.confidential_path = "/home/ubuntu/TTP-Lab/dashboard/static/img/confidential.png"
        
    def header(self):
        # Logo en haut à gauche
        if os.path.exists(self.logo_path):
            self.image(self.logo_path, 10, 8, 40)
        
        # Titre
        self.set_font('Arial', 'B', 20)
        self.set_text_color(255, 215, 0)  # Gold
        self.cell(0, 10, 'RAPPORT D\'ANALYSE D\'ATTAQUE', 0, 1, 'C')
        
        # Sous-titre
        self.set_font('Arial', '', 12)
        self.set_text_color(0, 0, 0)
        self.cell(0, 10, 'TTP-Lab - Be One And Move Academy', 0, 1, 'C')
        self.ln(5)
        
    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.set_text_color(128)
        self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')
        self.cell(0, 10, '© 2025 Mohammed Bencheikh - Be One And Move Academy', 0, 0, 'R')

    def add_confidential_stamp(self):
        """Ajoute le tampon CONFIDENTIEL"""
        if os.path.exists(self.confidential_path):
            self.image(self.confidential_path, 60, 120, 90)
    
    def chapter_title(self, title):
        self.set_font('Arial', 'B', 14)
        self.set_fill_color(255, 215, 0)  # Gold
        self.set_text_color(0, 0, 0)
        self.cell(0, 10, title, 0, 1, 'L', 1)
        self.ln(4)
    
    def chapter_body(self, body):
        self.set_font('Arial', '', 11)
        self.set_text_color(0, 0, 0)
        self.multi_cell(0, 6, body)
        self.ln()
    
    def add_code_block(self, code):
        self.set_font('Courier', '', 10)
        self.set_fill_color(240, 240, 240)
        self.multi_cell(0, 5, code, 1, 'L', 1)
        self.ln()


def create_attack_report(phase_data, output_path):
    """
    Génère un rapport PDF pour une phase d'attaque
    
    Args:
        phase_data: Dictionnaire contenant les données de la phase
        output_path: Chemin de sortie du PDF
    """
    
    pdf = AttackReportPDF()
    pdf.add_page()
    
    # Tampon CONFIDENTIEL
    pdf.add_confidential_stamp()
    
    # Section 1: Informations générales
    pdf.chapter_title('1. INFORMATIONS GENERALES')
    info_text = f"""Date du rapport : {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
Phase d'attaque : {phase_data.get('phase_name', 'N/A')}
Technique MITRE ATT&CK : {phase_data.get('technique', 'N/A')} - {phase_data.get('technique_name', 'N/A')}
Tactique MITRE ATT&CK : {phase_data.get('tactic', 'N/A')}
Statut : {'REUSSI' if phase_data.get('success') else 'ECHEC'}"""
    pdf.chapter_body(info_text)
    
    # Section 2: Description de l'attaque
    pdf.chapter_title('2. DESCRIPTION DE L\'ATTAQUE')
    pdf.chapter_body(phase_data.get('description', 'Aucune description disponible'))
    
    # Section 3: Payload utilisé
    pdf.chapter_title('3. PAYLOAD UTILISE')
    if 'payload_examples' in phase_data and len(phase_data['payload_examples']) > 0:
        payload = phase_data['payload_examples'][0].get('payload', 'N/A')
        pdf.add_code_block(payload)
    else:
        pdf.chapter_body('Aucun payload disponible')
    
    # Section 4: Analyse technique
    pdf.chapter_title('4. ANALYSE TECHNIQUE')
    pdf.chapter_body(phase_data.get('impact', 'Aucune analyse disponible'))
    
    # Section 5: Résultats des tests
    pdf.chapter_title('5. RESULTATS DES TESTS')
    if 'tests_performed' in phase_data:
        for test in phase_data['tests_performed']:
            test_name = test.get('test', 'Test')
            test_status = test.get('status', 'unknown')
            pdf.chapter_body(f"- {test_name}: {test_status.upper()}")
    else:
        pdf.chapter_body('Aucun test disponible')
    
    # Section 6: Indicateurs de compromission
    pdf.chapter_title('6. INDICATEURS DE COMPROMISSION (IOCs)')
    if 'detection_methods' in phase_data:
        for ioc in phase_data['detection_methods']:
            pdf.chapter_body(f"- {ioc}")
    else:
        pdf.chapter_body('Aucun IOC disponible')
    
    # Section 7: Méthodes de détection
    pdf.chapter_title('7. METHODES DE DETECTION')
    if 'data_sources' in phase_data:
        for source in phase_data['data_sources']:
            pdf.chapter_body(f"- {source}")
    else:
        pdf.chapter_body('Aucune méthode de détection disponible')
    
    # Section 8: Mitigations
    pdf.chapter_title('8. MITIGATIONS ET RECOMMANDATIONS')
    if 'mitigations' in phase_data:
        for mitigation in phase_data['mitigations']:
            pdf.chapter_body(f"- {mitigation}")
    else:
        pdf.chapter_body('Aucune mitigation disponible')
    
    # Section 9: Références
    pdf.chapter_title('9. REFERENCES')
    mitre_url = phase_data.get('mitre_url', 'https://attack.mitre.org')
    pdf.chapter_body(f"Documentation MITRE ATT&CK : {mitre_url}")
    
    # Sauvegarder le PDF
    try:
        pdf.output(output_path)
        print(f"[+] Rapport PDF généré avec succès : {output_path}")
        return True
    except Exception as e:
        print(f"[-] Erreur lors de la génération du PDF : {e}")
        return False


if __name__ == "__main__":
    # Test du générateur
    test_data = {
        "phase_name": "Initial Access",
        "technique": "T1190",
        "technique_name": "Exploit Public-Facing Application",
        "tactic": "TA0001 - Initial Access",
        "success": True,
        "description": "Exploitation d'une vulnérabilité d'injection de commande dans une application web publique.",
        "payload_examples": [{"payload": "test.txt'; whoami #"}],
        "impact": "Accès initial au système obtenu via exploitation d'application web",
        "tests_performed": [
            {"test": "Command Injection", "status": "success"},
            {"test": "System Enumeration", "status": "success"}
        ],
        "detection_methods": [
            "Surveiller les requêtes HTTP contenant des caractères suspects",
            "Détecter les exécutions de commandes système depuis des processus web"
        ],
        "data_sources": [
            "Application Log: Application Log Content",
            "Network Traffic: Network Traffic Content"
        ],
        "mitigations": [
            "Application Isolation and Sandboxing",
            "Exploit Protection",
            "Input Validation"
        ],
        "mitre_url": "https://attack.mitre.org/techniques/T1190/"
    }
    
    create_attack_report(test_data, "/home/ubuntu/TTP-Lab/reports/Test_Rapport.pdf")
