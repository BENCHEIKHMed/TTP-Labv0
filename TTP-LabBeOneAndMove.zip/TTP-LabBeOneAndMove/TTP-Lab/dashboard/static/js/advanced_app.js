/**
 * TTP-Lab Advanced JavaScript
 * Copyright © 2025 Mohammed Bencheikh - Be One And Move Academy
 * Interactions avancées et animations
 */

// ===== CONFIGURATION =====
const API_BASE = '/api';
let currentConfig = {
    victim_ip: '172.20.0.3',
    victim_port: 5000,
    attacker_ip: '172.20.0.2',
    c2_port: 4444
};

// ===== INITIALISATION =====
document.addEventListener('DOMContentLoaded', () => {
    console.log('%c🔒 TTP-Lab Dashboard Initialized', 'color: #FFD700; font-size: 16px; font-weight: bold');
    initializeAnimations();
    loadConfiguration();
    startRealTimeUpdates();
    initializeCharts();
});

// ===== ANIMATIONS AU CHARGEMENT =====
function initializeAnimations() {
    // Animation des cartes au scroll
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.card, .phase-card').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'all 0.6s ease-out';
        observer.observe(el);
    });

    // Effet de particules
    createParticles();
}

// ===== PARTICULES DE FOND =====
function createParticles() {
    const canvas = document.createElement('canvas');
    canvas.id = 'particles';
    canvas.style.position = 'fixed';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.zIndex = '-1';
    canvas.style.pointerEvents = 'none';
    document.body.appendChild(canvas);

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles = [];
    const particleCount = 50;

    for (let i = 0; i < particleCount; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            vx: (Math.random() - 0.5) * 0.5,
            vy: (Math.random() - 0.5) * 0.5,
            radius: Math.random() * 2 + 1
        });
    }

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        particles.forEach(p => {
            p.x += p.vx;
            p.y += p.vy;

            if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
            if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

            ctx.beginPath();
            ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(255, 215, 0, 0.3)';
            ctx.fill();
        });

        requestAnimationFrame(animate);
    }

    animate();

    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}

// ===== EXÉCUTION DES PHASES =====
async function executePhase(phaseId) {
    const phaseCard = document.querySelector(`[data-phase="${phaseId}"]`);
    const statusBadge = phaseCard.querySelector('.phase-status');
    const executeBtn = phaseCard.querySelector('.btn-execute');

    // Animation de démarrage
    executeBtn.disabled = true;
    executeBtn.innerHTML = '<span class="spinner"></span> Exécution...';
    statusBadge.className = 'phase-status status-running';
    statusBadge.textContent = 'EN COURS';

    try {
        const response = await fetch(`${API_BASE}/execute/${phaseId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(currentConfig)
        });

        const data = await response.json();

        if (data.success) {
            // Animation de succès
            statusBadge.className = 'phase-status status-success';
            statusBadge.textContent = '✓ RÉUSSI';
            executeBtn.innerHTML = '✓ Terminé';
            
            // Afficher le bouton de rapport
            if (data.report_url) {
                const reportBtn = document.getElementById(`report-${phaseId}`);
                if (reportBtn) {
                    reportBtn.href = data.report_url;
                    reportBtn.style.display = 'inline-block';
                    reportBtn.classList.add('pulse-animation');
                }
            }

            // Afficher la sortie
            displayOutput(data.output);
            
            // Notification de succès
            showNotification(`Phase ${phaseId} exécutée avec succès`, 'success');
            
            // Mettre à jour la timeline
            addTimelineEntry(data.timeline);
            
            // Rafraîchir les statistiques
            updateStatistics();
            
        } else {
            throw new Error(data.error || 'Erreur inconnue');
        }

    } catch (error) {
        // Animation d'erreur
        statusBadge.className = 'phase-status status-error';
        statusBadge.textContent = '✗ ÉCHEC';
        executeBtn.innerHTML = '↻ Réessayer';
        executeBtn.disabled = false;
        
        showNotification(`Erreur: ${error.message}`, 'error');
        console.error('Erreur d\'exécution:', error);
    }
}

// ===== AFFICHAGE DE LA SORTIE =====
function displayOutput(output) {
    const consoleEl = document.getElementById('console-output');
    if (!consoleEl) return;

    // Effet de typing
    const lines = output.split('\n');
    let currentLine = 0;

    const typeInterval = setInterval(() => {
        if (currentLine < lines.length) {
            const line = document.createElement('div');
            line.textContent = lines[currentLine];
            line.style.opacity = '0';
            consoleEl.appendChild(line);
            
            setTimeout(() => {
                line.style.transition = 'opacity 0.3s';
                line.style.opacity = '1';
            }, 10);
            
            currentLine++;
            consoleEl.scrollTop = consoleEl.scrollHeight;
        } else {
            clearInterval(typeInterval);
        }
    }, 50);
}

// ===== NOTIFICATIONS =====
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'slideInRight 0.4s ease-out reverse';
        setTimeout(() => notification.remove(), 400);
    }, 3000);
}

// ===== TIMELINE =====
function addTimelineEntry(entry) {
    const timeline = document.getElementById('attack-timeline');
    if (!timeline) return;

    const item = document.createElement('div');
    item.className = 'timeline-item';
    item.innerHTML = `
        <div class="timeline-content">
            <strong>${entry.phase}</strong>
            <p>${entry.description}</p>
            <small>${new Date(entry.timestamp).toLocaleString('fr-FR')}</small>
        </div>
    `;
    
    timeline.appendChild(item);
    timeline.scrollTop = timeline.scrollHeight;
}

// ===== STATISTIQUES =====
async function updateStatistics() {
    try {
        const response = await fetch(`${API_BASE}/state`);
        const data = await response.json();

        // Animer les compteurs
        animateCounter('phases-completed', data.phases_completed.length);
        animateCounter('techniques-used', Object.keys(data.mitre_coverage).length);
        
        // Mettre à jour la progress bar
        const progress = (data.phases_completed.length / 6) * 100;
        updateProgressBar(progress);
        
    } catch (error) {
        console.error('Erreur de mise à jour des statistiques:', error);
    }
}

// ===== ANIMATION DES COMPTEURS =====
function animateCounter(elementId, targetValue) {
    const element = document.getElementById(elementId);
    if (!element) return;

    const currentValue = parseInt(element.textContent) || 0;
    const increment = (targetValue - currentValue) / 20;
    let current = currentValue;

    const interval = setInterval(() => {
        current += increment;
        if ((increment > 0 && current >= targetValue) || (increment < 0 && current <= targetValue)) {
            element.textContent = targetValue;
            clearInterval(interval);
        } else {
            element.textContent = Math.floor(current);
        }
    }, 50);
}

// ===== PROGRESS BAR =====
function updateProgressBar(percentage) {
    const progressBar = document.querySelector('.progress-bar');
    if (progressBar) {
        progressBar.style.width = `${percentage}%`;
    }
}

// ===== GRAPHIQUES (Chart.js) =====
function initializeCharts() {
    // Graphique de couverture MITRE
    const mitreCtx = document.getElementById('mitre-coverage-chart');
    if (mitreCtx) {
        new Chart(mitreCtx, {
            type: 'radar',
            data: {
                labels: ['Initial Access', 'Execution', 'Persistence', 'Privilege Escalation', 'Collection', 'Exfiltration'],
                datasets: [{
                    label: 'Couverture ATT&CK',
                    data: [0, 0, 0, 0, 0, 0],
                    backgroundColor: 'rgba(255, 215, 0, 0.2)',
                    borderColor: 'rgba(255, 215, 0, 1)',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }
}

// ===== MISES À JOUR EN TEMPS RÉEL =====
function startRealTimeUpdates() {
    setInterval(updateStatistics, 5000);
    setInterval(refreshLogs, 10000);
}

// ===== RAFRAÎCHISSEMENT DES LOGS =====
async function refreshLogs() {
    try {
        const response = await fetch(`${API_BASE}/logs`);
        const data = await response.json();
        
        const logsContainer = document.getElementById('sysmon-logs');
        if (logsContainer && data.logs) {
            logsContainer.innerHTML = data.logs.join('\n');
            logsContainer.scrollTop = logsContainer.scrollHeight;
        }
    } catch (error) {
        console.error('Erreur de rafraîchissement des logs:', error);
    }
}

// ===== CONFIGURATION =====
function loadConfiguration() {
    const savedConfig = localStorage.getItem('ttp-lab-config');
    if (savedConfig) {
        currentConfig = JSON.parse(savedConfig);
        updateConfigForm();
    }
}

function saveConfiguration() {
    currentConfig = {
        victim_ip: document.getElementById('victim-ip').value,
        victim_port: parseInt(document.getElementById('victim-port').value),
        attacker_ip: document.getElementById('attacker-ip').value,
        c2_port: parseInt(document.getElementById('c2-port').value)
    };
    
    localStorage.setItem('ttp-lab-config', JSON.stringify(currentConfig));
    showNotification('Configuration sauvegardée', 'success');
}

function updateConfigForm() {
    document.getElementById('victim-ip').value = currentConfig.victim_ip;
    document.getElementById('victim-port').value = currentConfig.victim_port;
    document.getElementById('attacker-ip').value = currentConfig.attacker_ip;
    document.getElementById('c2-port').value = currentConfig.c2_port;
}

// ===== RÉINITIALISATION =====
async function resetSimulation() {
    if (!confirm('Voulez-vous vraiment réinitialiser la simulation ?')) return;

    try {
        const response = await fetch(`${API_BASE}/reset`, { method: 'POST' });
        const data = await response.json();
        
        if (data.success) {
            showNotification('Simulation réinitialisée', 'success');
            location.reload();
        }
    } catch (error) {
        showNotification('Erreur de réinitialisation', 'error');
    }
}

// ===== EXPORT DES FONCTIONS GLOBALES =====
window.executePhase = executePhase;
window.saveConfiguration = saveConfiguration;
window.resetSimulation = resetSimulation;
window.refreshLogs = refreshLogs;
