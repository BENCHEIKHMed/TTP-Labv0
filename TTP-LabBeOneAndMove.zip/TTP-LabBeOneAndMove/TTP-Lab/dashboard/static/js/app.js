/**
 * TTP-Lab Dashboard JavaScript
 * Copyright © 2025 Mohammed Bencheikh - Be One And Move Academy
 * EDUCATIONAL USE ONLY
 */

// État global
let currentState = {
    target_ip: '',
    target_port: 5000,
    attacker_ip: '',
    listener_port: 4444,
    phases_completed: [],
    attack_timeline: []
};

/**
 * Sauvegarde la configuration
 */
function saveConfiguration() {
    const config = {
        target_ip: document.getElementById('target_ip').value,
        target_port: document.getElementById('target_port').value,
        attacker_ip: document.getElementById('attacker_ip').value,
        listener_port: document.getElementById('listener_port').value
    };
    
    // Validation
    if (!config.target_ip || !config.attacker_ip) {
        showNotification('Veuillez remplir toutes les adresses IP', 'error');
        return;
    }
    
    fetch('/api/configure', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(config)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            currentState = { ...currentState, ...config };
            showNotification('Configuration enregistrée avec succès', 'success');
        } else {
            showNotification('Erreur lors de la sauvegarde', 'error');
        }
    })
    .catch(error => {
        console.error('Erreur:', error);
        showNotification('Erreur de connexion au serveur', 'error');
    });
}

/**
 * Exécute une phase d'attaque
 */
function executePhase(phaseId) {
    // Vérifier la configuration
    if (!currentState.target_ip || !currentState.attacker_ip) {
        showNotification('Veuillez d\'abord configurer les adresses IP', 'error');
        return;
    }
    
    // Mettre à jour le statut
    updatePhaseStatus(phaseId, 'running');
    
    // Afficher un message dans la console
    const outputDiv = document.getElementById('attack-output');
    outputDiv.innerHTML = `<p style="color: #FFD700;">[*] Lancement de la phase ${phaseId}...</p>`;
    
    // Exécuter la phase
    fetch(`/api/execute/${phaseId}`, {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updatePhaseStatus(phaseId, 'success');
            displayAttackOutput(data);
            addToTimeline(data.timeline);
            showNotification(`Phase ${data.phase.name} exécutée avec succès`, 'success');
            
            // Afficher le bouton de rapport
            if (data.report_url) {
                const reportButton = document.getElementById(`report-${phaseId}`);
                reportButton.href = data.report_url;
                reportButton.style.display = 'inline-block';
            }
            
            // Rafraîchir les logs automatiquement
            setTimeout(() => refreshLogs(), 2000);
        } else {
            updatePhaseStatus(phaseId, 'error');
            displayAttackOutput(data);
            showNotification(`Erreur lors de l'exécution : ${data.error}`, 'error');
        }
    })
    .catch(error => {
        console.error('Erreur:', error);
        updatePhaseStatus(phaseId, 'error');
        showNotification('Erreur de connexion au serveur', 'error');
    });
}

/**
 * Met à jour le statut d'une phase
 */
function updatePhaseStatus(phaseId, status) {
    const statusElement = document.getElementById(`status-${phaseId}`);
    const badge = statusElement.querySelector('.status-badge');
    
    badge.className = `status-badge ${status}`;
    
    const statusText = {
        'pending': 'En attente',
        'running': 'En cours...',
        'success': 'Réussi',
        'error': 'Erreur'
    };
    
    badge.textContent = statusText[status] || status;
}

/**
 * Affiche la sortie de l'attaque
 */
function displayAttackOutput(data) {
    const outputDiv = document.getElementById('attack-output');
    
    let html = '';
    
    if (data.phase) {
        html += `<div style="color: #FFD700; font-weight: bold; margin-bottom: 10px;">`;
        html += `=== ${data.phase.name} (${data.phase.technique_id}) ===`;
        html += `</div>`;
    }
    
    if (data.output) {
        html += `<pre style="color: #00ff00; white-space: pre-wrap;">${escapeHtml(data.output)}</pre>`;
    }
    
    if (data.error) {
        html += `<pre style="color: #FF3B30; white-space: pre-wrap;">ERREUR:\n${escapeHtml(data.error)}</pre>`;
    }
    
    outputDiv.innerHTML = html;
    outputDiv.scrollTop = outputDiv.scrollHeight;
}

/**
 * Rafraîchit les logs de la victime
 */
function refreshLogs() {
    const logsDiv = document.getElementById('victim-logs');
    logsDiv.innerHTML = '<p class="console-placeholder">Chargement des logs...</p>';
    
    fetch('/api/logs/victim')
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            logsDiv.innerHTML = `<pre style="color: #00ff00; white-space: pre-wrap;">${escapeHtml(data.logs)}</pre>`;
            logsDiv.scrollTop = logsDiv.scrollHeight;
            showNotification('Logs actualisés', 'success');
        } else {
            logsDiv.innerHTML = `<p style="color: #FF3B30;">Erreur: ${data.error}</p>`;
        }
    })
    .catch(error => {
        console.error('Erreur:', error);
        logsDiv.innerHTML = '<p style="color: #FF3B30;">Erreur de connexion</p>';
    });
}

/**
 * Ajoute un événement à la timeline
 */
function addToTimeline(timelineEntry) {
    const timelineContainer = document.getElementById('attack-timeline');
    
    // Supprimer le placeholder si présent
    const placeholder = timelineContainer.querySelector('.timeline-placeholder');
    if (placeholder) {
        placeholder.remove();
    }
    
    const timestamp = new Date(timelineEntry.timestamp).toLocaleString('fr-FR');
    const statusIcon = timelineEntry.success ? '✅' : '❌';
    
    const item = document.createElement('div');
    item.className = 'timeline-item';
    item.innerHTML = `
        <div class="timeline-time">${statusIcon} ${timestamp}</div>
        <div class="timeline-phase">${timelineEntry.phase_name}</div>
        <div class="timeline-technique">${timelineEntry.tactic} - ${timelineEntry.technique}</div>
    `;
    
    timelineContainer.insertBefore(item, timelineContainer.firstChild);
}

/**
 * Affiche une notification
 */
function showNotification(message, type) {
    // Créer l'élément de notification
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 25px;
        border-radius: 5px;
        color: white;
        font-weight: 600;
        z-index: 10000;
        animation: slideIn 0.3s ease;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    `;
    
    const colors = {
        'success': '#4CAF50',
        'error': '#FF3B30',
        'warning': '#FF9800',
        'info': '#FFD700'
    };
    
    notification.style.background = colors[type] || colors['info'];
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Supprimer après 3 secondes
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

/**
 * Échappe le HTML pour éviter les injections
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Charge l'état initial au chargement de la page
 */
document.addEventListener('DOMContentLoaded', function() {
    fetch('/api/state')
    .then(response => response.json())
    .then(data => {
        currentState = data;
        
        // Mettre à jour les champs de configuration
        if (data.target_ip) document.getElementById('target_ip').value = data.target_ip;
        if (data.target_port) document.getElementById('target_port').value = data.target_port;
        if (data.attacker_ip) document.getElementById('attacker_ip').value = data.attacker_ip;
        if (data.listener_port) document.getElementById('listener_port').value = data.listener_port;
        
        // Mettre à jour les statuts des phases
        data.phases_completed.forEach(phaseId => {
            updatePhaseStatus(phaseId, 'success');
        });
        
        // Afficher la timeline
        data.attack_timeline.forEach(entry => {
            addToTimeline(entry);
        });
    })
    .catch(error => {
        console.error('Erreur lors du chargement de l\'état:', error);
    });
    
    showNotification('Dashboard TTP-Lab chargé avec succès', 'success');
});

// Ajouter les animations CSS
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
