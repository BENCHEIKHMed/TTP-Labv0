# Documentation Technique - TTP-Lab

**Copyright © 2025 Mohammed Bencheikh - Be One And Move Academy**  
**CONFIDENTIEL - Usage Éducatif et Éthique Uniquement**

---

## Table des Matières

1. [Architecture Système](#architecture-système)
2. [Composants Principaux](#composants-principaux)
3. [API REST](#api-rest)
4. [Configuration Réseau](#configuration-réseau)
5. [Logs et Monitoring](#logs-et-monitoring)
6. [Procédures d'Intervention](#procédures-dintervention)
7. [Troubleshooting](#troubleshooting)

---

## Architecture Système

TTP-Lab est une plateforme éducative composée de trois conteneurs Docker interconnectés via un réseau privé.

### Schéma d'Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     TTP-Lab Platform                         │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │   Dashboard  │    │   Attacker   │    │    Victim    │  │
│  │              │    │              │    │              │  │
│  │  Flask App   │◄───┤  Python      │───►│  Flask App   │  │
│  │  Port: 8000  │    │  Scripts     │    │  Port: 5000  │  │
│  │              │    │              │    │  + Sysmon    │  │
│  └──────────────┘    └──────────────┘    └──────────────┘  │
│         │                   │                    │           │
│         └───────────────────┴────────────────────┘           │
│                      Network: ttp-lab-net                    │
│                      Subnet: 172.20.0.0/16                   │
└─────────────────────────────────────────────────────────────┘
```

### Adresses IP

| Composant | Adresse IP | Ports Exposés |
|-----------|------------|---------------|
| Dashboard | 172.20.0.4 | 8000 → localhost:8000 |
| Attacker  | 172.20.0.2 | 4444 (C2 Listener) |
| Victim    | 172.20.0.3 | 5000 (Web App) |

---

## Composants Principaux

### 1. Dashboard (Interface de Contrôle)

**Technologie** : Flask + JavaScript + CSS3

**Fonctionnalités** :
- Contrôle centralisé des phases d'attaque
- Visualisation en temps réel des logs Sysmon
- Génération automatique de rapports PDF
- Mapping MITRE ATT&CK interactif
- Timeline des événements

**Fichiers Clés** :
- `/dashboard/app.py` : Application Flask principale
- `/dashboard/report_generator.py` : Générateur de rapports PDF
- `/dashboard/templates/index.html` : Interface principale
- `/dashboard/static/js/advanced_app.js` : Logique JavaScript
- `/dashboard/static/css/advanced_style.css` : Styles avancés

### 2. Attacker (Machine Attaquante)

**Technologie** : Ubuntu 22.04 + Python 3

**Outils Installés** :
- Metasploit Framework
- Nmap
- Netcat
- Python 3 avec bibliothèques (requests, paramiko)

**Scripts d'Attaque** :
- `phase1_initial_access.py` : T1190 - Exploit Public-Facing Application
- `phase2_execution.py` : T1059.004 - Unix Shell
- `phase3_persistence.py` : T1053.003 - Cron
- `phase4_privilege_escalation.py` : T1548.003 - Sudo
- `phase5_collection.py` : T1005 - Data from Local System
- `phase6_exfiltration.py` : T1041 - Exfiltration Over C2 Channel

### 3. Victim (Machine Victime)

**Technologie** : Ubuntu 22.04 + Flask + Sysmon for Linux

**Vulnérabilités Intentionnelles** :
- Injection de commande dans l'application web (paramètre `filename`)
- Configuration sudo permissive pour l'utilisateur `webuser`
- Fichiers secrets non protégés dans `/home/webuser/secrets/`

**Monitoring** :
- Sysmon for Linux (collecte d'événements système)
- Rsyslog (centralisation des logs)
- Logs disponibles dans `/var/log/syslog`

---

## API REST

Le Dashboard expose une API REST pour contrôler les simulations d'attaque.

### Endpoints Disponibles

#### 1. Exécuter une Phase d'Attaque

```http
POST /api/execute/<phase_id>
Content-Type: application/json

{
  "victim_ip": "172.20.0.3",
  "victim_port": 5000,
  "attacker_ip": "172.20.0.2",
  "c2_port": 4444
}
```

**Réponse** :
```json
{
  "success": true,
  "phase": {
    "id": "phase1",
    "name": "Initial Access",
    "technique": "T1190"
  },
  "output": "...",
  "report_url": "/reports/Rapport_phase1.pdf",
  "timeline": {
    "phase": "Phase 1",
    "timestamp": "2025-11-30T17:00:00",
    "description": "Exploitation réussie"
  }
}
```

#### 2. Récupérer l'État de la Simulation

```http
GET /api/state
```

**Réponse** :
```json
{
  "phases_completed": ["phase1", "phase2"],
  "current_phase": "phase3",
  "mitre_coverage": {
    "T1190": {"name": "Exploit Public-Facing Application", "executed": true},
    "T1059.004": {"name": "Unix Shell", "executed": true}
  },
  "attack_timeline": [...]
}
```

#### 3. Récupérer les Logs Sysmon

```http
GET /api/logs
```

**Réponse** :
```json
{
  "logs": [
    "Nov 30 17:00:01 victim sysmon: EventID=1 ProcessCreate ...",
    "Nov 30 17:00:02 victim sysmon: EventID=3 NetworkConnect ..."
  ]
}
```

#### 4. Réinitialiser la Simulation

```http
POST /api/reset
```

**Réponse** :
```json
{
  "success": true,
  "message": "Simulation réinitialisée"
}
```

#### 5. Télécharger un Rapport

```http
GET /reports/<filename>
```

Retourne le fichier PDF du rapport.

---

## Configuration Réseau

### Docker Compose

Le fichier `docker-compose.yml` définit le réseau et les services.

```yaml
networks:
  ttp-lab-net:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/16
```

### Communication Inter-Conteneurs

Les conteneurs communiquent via le réseau `ttp-lab-net`. Les adresses IP sont statiques pour faciliter la configuration.

**Exemple de Test de Connectivité** :
```bash
# Depuis le conteneur Attacker
docker exec ttp-lab-attacker ping -c 3 172.20.0.3

# Depuis le conteneur Dashboard
docker exec ttp-lab-dashboard curl http://172.20.0.3:5000
```

---

## Logs et Monitoring

### Sysmon for Linux

Sysmon est configuré pour capturer les événements suivants :
- **EventID 1** : Création de processus
- **EventID 3** : Connexion réseau
- **EventID 11** : Création de fichier
- **EventID 23** : Suppression de fichier

**Configuration** : `/etc/sysmon-config.xml`

### Visualisation des Logs

**Depuis le Dashboard** :
- Section "Logs Sysmon" avec rafraîchissement automatique toutes les 10 secondes

**Depuis la CLI** :
```bash
# Logs en temps réel
docker exec ttp-lab-victim tail -f /var/log/syslog

# Filtrer les événements Sysmon
docker exec ttp-lab-victim grep "sysmon" /var/log/syslog

# Rechercher des événements spécifiques
docker exec ttp-lab-victim grep "EventID=1" /var/log/syslog | grep "cmd.exe"
```

---

## Procédures d'Intervention

### Scénario 1 : Détection d'une Injection de Commande (T1190)

**Indicateurs** :
- Requêtes HTTP POST contenant des caractères suspects (`;`, `|`, `&`)
- Exécution de commandes système depuis le processus `python3` (application web)

**Requête de Détection** (Splunk) :
```spl
index=web sourcetype=access_combined 
| search form_data=*";"* OR form_data=*"|"* OR form_data=*"&"*
| table _time, src_ip, form_data
```

**Actions de Réponse** :
1. Isoler le serveur web du réseau
2. Analyser les logs d'accès pour identifier l'attaquant
3. Vérifier l'intégrité des fichiers système
4. Patcher l'application (validation des entrées)

### Scénario 2 : Détection de Persistance via Cron (T1053.003)

**Indicateurs** :
- Modification du fichier `/var/spool/cron/crontabs/webuser`
- Création de processus par cron avec des commandes suspectes

**Requête de Détection** (Auditd) :
```bash
ausearch -k cron-access
```

**Actions de Réponse** :
1. Lister les tâches cron : `crontab -l -u webuser`
2. Supprimer les tâches malveillantes : `crontab -r -u webuser`
3. Auditer les autres mécanismes de persistance

### Scénario 3 : Détection d'Élévation de Privilèges (T1548.003)

**Indicateurs** :
- Utilisation de `sudo` par un utilisateur non privilégié
- Exécution de binaires SUID/SGID suspects

**Requête de Détection** (Sysmon) :
```bash
grep "EventID=1" /var/log/syslog | grep "sudo" | grep "find"
```

**Actions de Réponse** :
1. Restreindre les privilèges sudo : éditer `/etc/sudoers`
2. Auditer les binaires SUID : `find / -perm -4000 -ls`
3. Révoquer les sessions de l'utilisateur compromis

---

## Troubleshooting

### Problème : Les Conteneurs ne Démarrent Pas

**Symptômes** :
```bash
docker ps
# Aucun conteneur actif
```

**Solutions** :
1. Vérifier les logs :
   ```bash
   docker-compose logs
   ```
2. Reconstruire les images :
   ```bash
   docker-compose build --no-cache
   docker-compose up -d
   ```

### Problème : Le Dashboard ne Génère pas de Rapports PDF

**Symptômes** :
- Bouton "Télécharger le Rapport" n'apparaît pas
- Erreur 500 lors de l'exécution d'une phase

**Solutions** :
1. Vérifier que fpdf2 est installé :
   ```bash
   docker exec ttp-lab-dashboard pip3 list | grep fpdf2
   ```
2. Vérifier les permissions du répertoire `/reports` :
   ```bash
   docker exec ttp-lab-dashboard ls -ld /home/ubuntu/TTP-Lab/reports
   ```
3. Tester manuellement le générateur :
   ```bash
   docker exec ttp-lab-dashboard python3 /home/ubuntu/TTP-Lab/dashboard/report_generator.py
   ```

### Problème : Les Logs Sysmon ne S'affichent Pas

**Symptômes** :
- Section "Logs Sysmon" vide dans le dashboard

**Solutions** :
1. Vérifier que Sysmon est actif :
   ```bash
   docker exec ttp-lab-victim pgrep sysmon
   ```
2. Vérifier les logs manuellement :
   ```bash
   docker exec ttp-lab-victim tail -f /var/log/syslog | grep sysmon
   ```
3. Redémarrer Sysmon :
   ```bash
   docker exec ttp-lab-victim sysmon -u
   docker exec ttp-lab-victim sysmon -accepteula -i /etc/sysmon-config.xml
   ```

### Problème : Les Attaques Échouent

**Symptômes** :
- Statut "ÉCHEC" pour une phase
- Erreur de connexion dans les logs

**Solutions** :
1. Vérifier la connectivité réseau :
   ```bash
   docker exec ttp-lab-attacker ping -c 3 172.20.0.3
   ```
2. Vérifier que l'application victime est active :
   ```bash
   docker exec ttp-lab-victim curl http://localhost:5000
   ```
3. Consulter les logs de l'attaquant :
   ```bash
   docker logs ttp-lab-attacker
   ```

---

## Annexes

### Mapping MITRE ATT&CK Complet

| Phase | Tactique | Technique | ID | Description |
|-------|----------|-----------|-----|-------------|
| 1 | Initial Access | Exploit Public-Facing Application | T1190 | Injection de commande dans l'application web |
| 2 | Execution | Command and Scripting Interpreter: Unix Shell | T1059.004 | Exécution de commandes via bash |
| 3 | Persistence | Scheduled Task/Job: Cron | T1053.003 | Création d'une tâche cron malveillante |
| 4 | Privilege Escalation | Abuse Elevation Control Mechanism: Sudo | T1548.003 | Exploitation de sudo pour obtenir root |
| 5 | Collection | Data from Local System | T1005 | Collecte de fichiers sensibles |
| 6 | Exfiltration | Exfiltration Over C2 Channel | T1041 | Exfiltration via connexion C2 |

### Références

- [MITRE ATT&CK Framework](https://attack.mitre.org/)
- [Sysmon for Linux Documentation](https://github.com/Sysinternals/SysmonForLinux)
- [Docker Documentation](https://docs.docker.com/)
- [Flask Documentation](https://flask.palletsprojects.com/)

---

**Document généré le 30 novembre 2025**  
**Auteur : Mohammed Bencheikh**  
**Be One And Move Academy - The Leader of Cyber Courses**
