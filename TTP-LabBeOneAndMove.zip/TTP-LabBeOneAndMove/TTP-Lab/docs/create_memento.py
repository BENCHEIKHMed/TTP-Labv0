#!/usr/bin/env python3
"""
Memento Engineer PDF Generator
Copyright © 2025 Mohammed Bencheikh - Be One And Move Academy
"""

from fpdf import FPDF

class MementoPDF(FPDF):
    def __init__(self):
        super().__init__()
        self.logo_path = "/home/ubuntu/TTP-Lab/dashboard/static/img/logo.jpg"

    def header(self):
        self.image(self.logo_path, 10, 8, 33)
        self.set_font("Arial", "B", 15)
        self.cell(80)
        self.cell(30, 10, "Memento Engineer - MITRE ATT&CK", 0, 0, "C")
        self.ln(20)

    def footer(self):
        self.set_y(-15)
        self.set_font("Arial", "I", 8)
        self.cell(0, 10, f"Page {self.page_no()}/{{nb}}", 0, 0, "C")
        self.cell(0, 10, "© 2025 Mohammed Bencheikh - Be One And Move Academy", 0, 0, "R")

    def chapter_title(self, title):
        self.set_font("Arial", "B", 12)
        self.set_fill_color(255, 215, 0) # Gold
        self.cell(0, 6, title, 0, 1, "L", 1)
        self.ln(4)

    def chapter_body(self, body):
        self.set_font("Arial", "", 11)
        self.multi_cell(0, 5, body)
        self.ln()

    def add_code_block(self, code):
        self.set_font("Courier", "", 10)
        self.set_fill_color(240, 240, 240)
        self.multi_cell(0, 5, code, 1, "L", 1)
        self.ln()

def create_memento_pdf(output_path):
    pdf = MementoPDF()
    pdf.alias_nb_pages()
    pdf.add_page()

    # Introduction
    pdf.chapter_title("Introduction")
    pdf.chapter_body("Ce document est un aide-mémoire pour les ingénieurs et analystes en cybersécurité. Il fournit des informations clés sur les tactiques et techniques MITRE ATT&CK, des requêtes de threat hunting, et des procédures de réponse immédiate.")

    # Initial Access
    pdf.chapter_title("TA0001 - Initial Access")
    pdf.chapter_body("Objectif : Obtenir un premier accès au réseau de la cible.")
    pdf.add_code_block("Exemple de requête (Splunk) :\nindex=* sourcetype=proxy http_method=POST (form_data=*whoami* OR form_data=*uname*)")

    # Execution
    pdf.chapter_title("TA0002 - Execution")
    pdf.chapter_body("Objectif : Exécuter du code malveillant sur un système local ou distant.")
    pdf.add_code_block("Exemple de requête (Sysmon) :\nEventCode=1 (process_creation) ParentImage=*w3wp.exe* Image=*cmd.exe*")

    # Persistence
    pdf.chapter_title("TA0003 - Persistence")
    pdf.chapter_body("Objectif : Maintenir l'accès à un système compromis.")
    pdf.add_code_block("Exemple de requête (Auditd) :\ntype=SYSCALL key=cron-access	")

    # Privilege Escalation
    pdf.chapter_title("TA0004 - Privilege Escalation")
    pdf.chapter_body("Objectif : Obtenir des privilèges plus élevés sur un système.")
    pdf.add_code_block("Exemple de requête (Sysmon) :\nEventCode=1 (process_creation) ParentImage=*sudo* Image=*find*")

    # Collection
    pdf.chapter_title("TA0009 - Collection")
    pdf.chapter_body("Objectif : Collecter des données d'intérêt pour l'attaquant.")
    pdf.add_code_block("Exemple de requête (Sysmon) :\nEventCode=1 (process_creation) Image=*cat* CommandLine=*shadow*")

    # Exfiltration
    pdf.chapter_title("TA0010 - Exfiltration")
    pdf.chapter_body("Objectif : Exfiltrer des données du réseau de la cible.")
    pdf.add_code_block("Exemple de requête (Splunk) :\nindex=* sourcetype=proxy bytes_out>1000000")

    pdf.output(output_path)

if __name__ == "__main__":
    create_memento_pdf("/home/ubuntu/TTP-Lab/docs/Memento_Engineer_MITRE_ATTACK.pdf")
