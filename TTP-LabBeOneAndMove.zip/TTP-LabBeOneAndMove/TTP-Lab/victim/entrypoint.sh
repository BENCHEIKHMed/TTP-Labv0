#!/bin/bash
################################################################################
# Script de démarrage de l'environnement Victime - TTP-Lab
# Copyright © 2025 Mohammed Bencheikh - Be One And Move Academy
# USAGE ÉDUCATIF ET ÉTHIQUE UNIQUEMENT
################################################################################

echo "=========================================="
echo "  TTP-Lab Victim Environment"
echo "  Be One And Move Academy"
echo "=========================================="
echo ""

# Démarrer rsyslog pour la collecte des logs
echo "[*] Démarrage de rsyslog..."
service rsyslog start
sleep 2

# Vérifier si Sysmon est installé
if command -v sysmon &> /dev/null; then
    echo "[*] Configuration de Sysmon for Linux..."
    
    # Arrêter Sysmon s'il est déjà en cours d'exécution
    sysmon -u 2>/dev/null || true
    sleep 1
    
    # Démarrer Sysmon avec la configuration
    if [ -f "/etc/sysmon-config.xml" ]; then
        sysmon -accepteula -i /etc/sysmon-config.xml 2>&1
        echo "[+] Sysmon démarré avec configuration personnalisée"
    else
        sysmon -accepteula -i 2>&1
        echo "[+] Sysmon démarré avec configuration par défaut"
    fi
    
    sleep 2
    
    # Vérifier que Sysmon fonctionne
    if pgrep -x "sysmon" > /dev/null; then
        echo "[+] Sysmon est actif (PID: $(pgrep -x sysmon))"
        
        # Vérifier que les logs sont générés
        echo "[*] Test de génération de logs Sysmon..."
        whoami > /dev/null
        sleep 1
        
        if grep -q "sysmon" /var/log/syslog 2>/dev/null; then
            echo "[+] Logs Sysmon opérationnels"
        else
            echo "[!] Avertissement : Logs Sysmon non détectés dans /var/log/syslog"
        fi
    else
        echo "[-] Avertissement : Sysmon ne semble pas actif"
    fi
else
    echo "[-] Sysmon n'est pas installé - Les logs seront limités"
fi

# Démarrer SSH
echo "[*] Démarrage du service SSH..."
service ssh start

# Démarrer cron
echo "[*] Démarrage du service cron..."
service cron start

# Créer l'utilisateur webuser s'il n'existe pas
if ! id "webuser" &>/dev/null; then
    echo "[*] Création de l'utilisateur webuser..."
    useradd -m -s /bin/bash webuser
    echo "webuser:Password123" | chpasswd
    echo "[+] Utilisateur webuser créé"
fi

# Configuration sudo vulnérable pour webuser
echo "[*] Configuration des privilèges sudo (vulnérable)..."
echo "webuser ALL=(ALL) NOPASSWD: /usr/bin/find" >> /etc/sudoers
echo "[+] Configuration sudo appliquée"

# Créer des fichiers secrets pour la simulation
echo "[*] Création des fichiers secrets..."
mkdir -p /home/webuser/secrets
echo "API_KEY=sk-1234567890abcdef" > /home/webuser/secrets/api_keys.txt
echo "DB_PASSWORD=SuperSecret123!" > /home/webuser/secrets/db_config.txt
echo "ADMIN_TOKEN=admin_token_xyz789" > /home/webuser/secrets/admin_token.txt
chown -R webuser:webuser /home/webuser/secrets
chmod 600 /home/webuser/secrets/*
echo "[+] Fichiers secrets créés"

# Copier l'application web dans le home de webuser
cp /opt/vulnerable_app.py /home/webuser/app.py
chown webuser:webuser /home/webuser/app.py

# Démarrer l'application web vulnérable
echo "[*] Démarrage de l'application web vulnérable..."
su - webuser -c "cd /home/webuser && python3 app.py > /tmp/webapp.log 2>&1 &"
sleep 2

# Vérifier que l'application est démarrée
if pgrep -f "python3 app.py" > /dev/null; then
    APP_PID=$(pgrep -f "python3 app.py")
    echo "[+] Application web démarrée (PID: $APP_PID)"
else
    echo "[-] Erreur : L'application web n'a pas démarré"
    cat /tmp/webapp.log
fi

echo ""
echo "=========================================="
echo "  Environnement Victime Prêt"
echo "=========================================="
echo "  Application web : http://172.20.0.3:5000"
echo "  Utilisateur : webuser"
echo "  Mot de passe : Password123"
echo "  Sysmon : $(pgrep -x sysmon > /dev/null && echo 'Actif' || echo 'Inactif')"
echo "  Logs : /var/log/syslog"
echo "=========================================="
echo ""

# Afficher les logs en temps réel
echo "[*] Affichage des logs en temps réel..."
tail -f /var/log/syslog
