#!/usr/bin/env python3
"""
Vulnerable Web Application for TTP-Lab
Copyright © 2025 Mohammed Bencheikh - Be One And Move Academy
EDUCATIONAL USE ONLY - DO NOT DEPLOY IN PRODUCTION

This application contains INTENTIONAL security vulnerabilities for training purposes.
"""

from flask import Flask, request, render_template_string
import subprocess
import os

app = Flask(__name__)

# Template HTML simple
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Corporate File Manager - Be One And Move</title>
    <style>
        body {
            font-family: Calibri, sans-serif;
            background: linear-gradient(135deg, #1E1E1E 0%, #2D2D2D 100%);
            color: #EAEAEA;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            background: #2A2A2A;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(255, 215, 0, 0.3);
        }
        h1 {
            color: #FFD700;
            text-align: center;
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        .subtitle {
            text-align: center;
            color: #AAAAAA;
            margin-bottom: 30px;
        }
        input[type="text"] {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            background: #1E1E1E;
            border: 2px solid #FFD700;
            color: #EAEAEA;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #FFD700;
            color: #1E1E1E;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
        }
        button:hover {
            background: #FFC700;
            transform: translateY(-2px);
        }
        .result {
            margin-top: 20px;
            padding: 15px;
            background: #1E1E1E;
            border-left: 4px solid #FFD700;
            white-space: pre-wrap;
            font-family: monospace;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            color: #666666;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📁 File Manager</h1>
        <div class="subtitle">Corporate Document Search System</div>
        
        <form method="POST" action="/search">
            <label for="filename">Enter filename to search:</label>
            <input type="text" id="filename" name="filename" placeholder="e.g., report.txt" required>
            <button type="submit">🔍 Search Files</button>
        </form>
        
        {% if result %}
        <div class="result">
            <strong>Search Results:</strong><br>
            {{ result }}
        </div>
        {% endif %}
        
        <div class="footer">
            © 2025 Be One And Move Academy - Educational Platform<br>
            <strong>WARNING:</strong> This system contains intentional vulnerabilities for training purposes only.
        </div>
    </div>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/search', methods=['POST'])
def search():
    """
    VULNERABILITY: Command Injection (T1190)
    Cette fonction exécute directement l'entrée utilisateur sans validation.
    """
    filename = request.form.get('filename', '')
    
    # VULNÉRABILITÉ INTENTIONNELLE : Injection de commande
    # L'entrée utilisateur est directement passée au shell
    try:
        command = f"find /home/webuser -name '{filename}' 2>/dev/null"
        result = subprocess.check_output(command, shell=True, text=True, timeout=5)
        
        if not result:
            result = "No files found matching your search."
    except subprocess.TimeoutExpired:
        result = "Search timeout. Please try a more specific query."
    except Exception as e:
        result = f"Error during search: {str(e)}"
    
    return render_template_string(HTML_TEMPLATE, result=result)

@app.route('/health')
def health():
    """Endpoint de santé pour monitoring"""
    return {"status": "running", "app": "TTP-Lab Victim"}

if __name__ == '__main__':
    # Démarrer l'application sur toutes les interfaces
    app.run(host='0.0.0.0', port=5000, debug=False)
